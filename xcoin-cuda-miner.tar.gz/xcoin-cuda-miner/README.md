# xcoin-cuda-miner

Miner MetalDAG (xCoin / XID) cho GPU NVIDIA: CMP 90HX/70HX, RTX 20/30/40, GTX 10/16.
Đây là bản port độc lập sang CUDA của thuật toán trong `github.com/SystemThreat/xCoin`
(`src/metaldag/metaldag.cpp`, `miner/MetalDAGShader.swift`). Không dev fee, không telemetry.

## Trạng thái kiểm chứng

**Đã kiểm (trên máy không có GPU):**
- Lõi hash (keccak, DAG item, hashimoto, thuật toán 8-lane của kernel) được so với code consensus
  của node, trích nguyên văn từ `metaldag.cpp`. Kiểm ở kích thước mainnet epoch 0 thật (DAG 4 GiB, cache 32 MiB).
- Dựng header, merkle, target, JSON được so với vector sinh từ chính `xcoin-pool.py`.
- End-to-end với **`xcoin-pool.py` thật** (chỉ giả lập RPC node, PoW tính bằng code node), cả solo
  lẫn PPLNS: share được chấp nhận, vardiff, nhánh tìm block, không bị ngắt vì submit flood.
- Device code compile cho sm_61/75/86 (clang + ptxas của NVIDIA): 71 register, 0 spill.

**Chưa kiểm:** chạy trên GPU thật, hashrate thực tế, build bằng nvcc.

**Hai lớp bảo vệ khi chạy:**
1. Sau khi dựng DAG, miner tự so 16 DAG item và 6 hash từ GPU với CPU (cộng 1 vector cố định của
   epoch 0). Lệch một byte là GPU đó dừng, không đào.
2. Mọi share GPU tìm ra đều được CPU tính lại đúng như node của pool trước khi gửi. Share sai bị
   đếm vào `hw_errors` và không gửi đi.

## Build

Cần **một** trong hai: CUDA toolkit (có `nvcc`) hoặc Docker.

```sh
./build.sh
```

Không có `nvcc` thì script build trong Docker `nvidia/cuda:11.8.0-devel-ubuntu20.04`. Bản đó dùng
glibc cũ và CUDA 11 runtime nên chạy được trên HiveOS và driver NVIDIA ≥ 450.80. Binary link
tĩnh cudart, trên rig chỉ cần driver.

Không nên build trên HiveOS. Build trên máy Ubuntu bất kỳ rồi copy file `xcoin-cuda-miner` sang.

## Chạy thử, theo thứ tự

```sh
./xcoin-cuda-miner --selftest          # dựng DAG, so GPU với CPU rồi thoát
./xcoin-cuda-miner --benchmark 60      # đo hashrate 60 giây, không cần pool
./xcoin-cuda-miner -o 198.252.101.117:3336 -u xpa1r...ĐỊA_CHỈ.rig01
```

| Tuỳ chọn | Ý nghĩa |
|---|---|
| `-o HOST:PORT` | pool, lặp lại để có failover. PPLNS SG `198.252.101.117:3336`, solo NY `pool.xcoinminer.com:3335` |
| `-u ADDR[.WORKER]` | địa chỉ payout `xpa1r…`, có thể kèm `.worker` |
| `-d 0,1,2` | chọn GPU (mặc định dùng tất cả) |
| `--batch N` | số nonce mỗi lần launch = 2^N (mặc định 22) |
| `--base T` | gốc epoch MetalDAG (mặc định genesis mainnet 1790380800) |
| `--stats-file PATH` | ghi JSON thống kê mỗi 10 giây |

Mỗi 10 giây miner in hashrate từng GPU, số share A/R và độ khó của pool.

## HiveOS

```sh
./package-hiveos.sh        # tạo xcoin-cuda-miner-0.1.0.tar.gz
```

Flight sheet:
- Miner: **Custom**. Installation URL: link tới file `.tar.gz`, ví dụ GitHub release của bạn.
- Hash algorithm: `metaldag`.
- Wallet and worker template: `%WAL%.%WORKER_NAME%`. Wallet là địa chỉ `xpa1r…`.
- Pool URL: `198.252.101.117:3336`.
- Extra config arguments: để trống, hoặc `--devices 0,1`.

`h-stats.sh` gửi hashrate, nhiệt độ, quạt, bus và A/R lên dashboard HiveOS. Nhiệt và quạt lấy từ
`nvidia-smi` theo thứ tự PCI bus, khớp khi dùng toàn bộ GPU NVIDIA trên rig.

## Ghi chú

- DAG 4 GiB, tăng 128 MiB mỗi 14 ngày. Epoch 1 bắt đầu 2026-10-10 00:00 UTC. Miner tự dựng lại DAG
  khi job sang epoch mới, và tạm ngừng đào trong lúc dựng.
- VRAM cần khoảng 4.1 GiB trống trở lên: CMP 70HX (8 GB) và 90HX (10 GB) đều đủ.
- Dev của xCoin quảng bá coin là "ưu ái Apple Silicon". Nếu họ đổi thuật toán PoW, miner này sẽ
  bị từ chối mọi share và phải cập nhật lại.

## Kiểm lại phía CPU

```sh
git clone --depth 1 https://github.com/SystemThreat/xCoin /tmp/xCoin
tests/run_tests.sh
```

`tests/mock_pool.py` chạy `xcoin-pool.py` thật với RPC giả lập. Kết hợp cờ ẩn `--cpu-mine` của
miner để thử toàn bộ giao thức mà không cần GPU.

MIT License.
