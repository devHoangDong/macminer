#!/usr/bin/env bash
# Build xcoin-cuda-miner. Uses a local nvcc if present, otherwise Docker with the
# CUDA 11.8 / Ubuntu 20.04 toolchain (old glibc + CUDA 11 runtime = runs on HiveOS
# and on NVIDIA drivers >= 450.80). Override: CUDA_IMAGE=nvidia/cuda:12.4.1-devel-ubuntu22.04 ./build.sh
set -euo pipefail
cd "$(dirname "$0")"
if command -v nvcc >/dev/null 2>&1; then
  echo "[build] using local $(nvcc --version | tail -1)"
  make -j"$(nproc)" xcoin-cuda-miner
elif command -v docker >/dev/null 2>&1; then
  IMG="${CUDA_IMAGE:-nvidia/cuda:11.8.0-devel-ubuntu20.04}"
  echo "[build] no local nvcc; building inside $IMG"
  docker run --rm -v "$PWD":/src -w /src "$IMG" bash -c "make -j\$(nproc) xcoin-cuda-miner && chown $(id -u):$(id -g) xcoin-cuda-miner"
else
  echo "Need either nvcc (CUDA toolkit) or docker. On Ubuntu: sudo apt install docker.io" >&2; exit 1
fi
ls -la xcoin-cuda-miner
echo "[build] done. Next: ./xcoin-cuda-miner --selftest"
