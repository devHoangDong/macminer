#!/usr/bin/env bash
# Builds xcoin-cuda-miner-<ver>.tar.gz in the HiveOS custom-miner layout.
set -euo pipefail
cd "$(dirname "$0")"
[[ -x xcoin-cuda-miner ]] || ./build.sh
VER=$(grep CUSTOM_VERSION hiveos/xcoin-cuda-miner/h-manifest.conf | cut -d= -f2)
rm -rf dist && mkdir -p dist/xcoin-cuda-miner
cp hiveos/xcoin-cuda-miner/* dist/xcoin-cuda-miner/
cp xcoin-cuda-miner dist/xcoin-cuda-miner/
tar -C dist -czf "xcoin-cuda-miner-$VER.tar.gz" xcoin-cuda-miner
echo "created xcoin-cuda-miner-$VER.tar.gz"
