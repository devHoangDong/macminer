#!/usr/bin/env bash
# Flight sheet -> command line.
#   Wallet and worker template: %WAL%.%WORKER_NAME%
#   Pool URL: 198.252.101.117:3336   (PPLNS, Singapore)  or  pool.xcoinminer.com:3335 (solo)
#   Extra config arguments: anything else, e.g. --devices 0,1,2
[[ -z $CUSTOM_TEMPLATE ]] && echo "CUSTOM_TEMPLATE (wallet.worker) is empty" && return 1
[[ -z $CUSTOM_URL ]] && echo "CUSTOM_URL (pool host:port) is empty" && return 1
. /hive/miners/custom/xcoin-cuda-miner/h-manifest.conf
conf=""
for url in $CUSTOM_URL; do conf+=" -o ${url#stratum+tcp://}"; done
conf+=" -u $CUSTOM_TEMPLATE"
[[ -n $CUSTOM_PASS ]] && conf+=" -p $CUSTOM_PASS"
conf+=" --stats-file $STATS_FILE"
[[ -n $CUSTOM_USER_CONFIG ]] && conf+=" $CUSTOM_USER_CONFIG"
echo "$conf" > "$CUSTOM_CONFIG_FILENAME"
