#!/usr/bin/env bash
cd "$(dirname "$0")"
. h-manifest.conf
[[ -f $CUSTOM_CONFIG_FILENAME ]] || { echo "No config $CUSTOM_CONFIG_FILENAME"; exit 1; }
mkdir -p "$(dirname "$CUSTOM_LOG_BASENAME")"
export CUDA_DEVICE_ORDER=PCI_BUS_ID      # same GPU order as nvidia-smi / HiveOS
./xcoin-cuda-miner $(< "$CUSTOM_CONFIG_FILENAME") 2>&1 | tee --append "${CUSTOM_LOG_BASENAME}.log"
