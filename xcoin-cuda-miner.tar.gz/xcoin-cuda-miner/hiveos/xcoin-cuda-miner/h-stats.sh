#!/usr/bin/env bash
# Sourced by the HiveOS agent: must set $khs and $stats.
. /hive/miners/custom/xcoin-cuda-miner/h-manifest.conf
khs=0; stats=""
if [[ -f $STATS_FILE ]] && (( $(date +%s) - $(stat -c %Y "$STATS_FILE") < 60 )); then
  data=$(cat "$STATS_FILE")
  khs=$(jq '.total_hs/1000' <<< "$data")
  hs=$(jq -c '[.hs[]/1000]' <<< "$data")
  temp=$(nvidia-smi --query-gpu=temperature.gpu --format=csv,noheader,nounits 2>/dev/null | jq -Rsc 'split("\n")|map(select(length>0)|tonumber? // 0)')
  fan=$(nvidia-smi --query-gpu=fan.speed --format=csv,noheader,nounits 2>/dev/null | jq -Rsc 'split("\n")|map(select(length>0)|tonumber? // 0)')
  bus="["; first=1
  for b in $(nvidia-smi --query-gpu=pci.bus --format=csv,noheader 2>/dev/null); do
    [[ $first == 1 ]] || bus+=","; bus+=$(printf "%d" "$b"); first=0
  done; bus+="]"
  stats=$(jq -nc --argjson hs "$hs" --argjson temp "${temp:-[]}" --argjson fan "${fan:-[]}" --argjson bus "$bus" \
      --argjson up "$(jq '.uptime' <<< "$data")" --argjson acc "$(jq '.accepted' <<< "$data")" --argjson rej "$(jq '.rejected' <<< "$data")" \
      --arg ver "$CUSTOM_VERSION" \
      '{hs:$hs, hs_units:"khs", temp:$temp, fan:$fan, bus_numbers:$bus, uptime:$up, ar:[$acc,$rej], algo:"metaldag", ver:$ver}')
fi
[[ -z $khs ]] && khs=0
