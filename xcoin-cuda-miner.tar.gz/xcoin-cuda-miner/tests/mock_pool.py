# Runs the REAL xcoin-pool.py (github.com/SystemThreat/xCoin) with only its node RPC mocked.
# getmetaldagpowhash is answered by ./powcheck (the node's MetalDAG code, mainnet sizing).
import asyncio, importlib.util, os, subprocess, sys, threading, time, json
os.environ.setdefault("XCOIN_RPC_COOKIE", "/tmp/fakecookie"); open("/tmp/fakecookie","w").write("__cookie__:x")
os.environ["XCOIN_STRATUM_HOST"] = "127.0.0.1"
spec = importlib.util.spec_from_file_location("pool", "/tmp/xCoin/xcoin-pool/xcoin-pool.py")
pool = importlib.util.module_from_spec(spec); spec.loader.exec_module(pool)
BITS = os.environ.get("MOCK_BITS", "1d00ffff")
pc = subprocess.Popen([os.path.join(os.path.dirname(__file__), "powcheck")], stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)
lock = threading.Lock()
stats = {"pow_calls": 0, "submitblock": 0}
HEIGHT = [2700]; PREV = ["00" * 31 + "11"]; BEST = [""]
def fake_rpc(method, params=None):
    if method == "getblockchaininfo": return {"chain": "main", "blocks": HEIGHT[0]}
    if method == "getblocktemplate":
        now = int(time.time())
        return {"previousblockhash": PREV[0], "transactions": [], "coinbasevalue": 50 * 10**8, "height": HEIGHT[0] + 1,
                "bits": BITS, "curtime": now, "mintime": now - 600, "version": 0x20000000,
                "default_witness_commitment": "6a24aa21a9ed" + "00" * 32}
    if method == "getmetaldagpowhash":
        with lock:
            stats["pow_calls"] += 1
            pc.stdin.write(params[0] + "\n"); pc.stdin.flush(); return pc.stdout.readline().strip()
    if method == "getbestblockhash": return BEST[0]
    if method == "submitblock":
        stats["submitblock"] += 1
        import hashlib
        hdr = bytes.fromhex(params[0][:160]); BEST[0] = hashlib.sha256(hashlib.sha256(hdr).digest()).digest()[::-1].hex()
        HEIGHT[0] += 1; PREV[0] = "%064x" % (HEIGHT[0] * 7919)   # tip moves -> pool pushes a clean job
        return None
    return None
pool.rpc = fake_rpc
pool.natpmp_loop = lambda: asyncio.sleep(0)
async def report():
    while True:
        await asyncio.sleep(5)
        print("MOCK-STATS", json.dumps(stats), flush=True)
asyncio.get_event_loop_policy()
async def runner():
    asyncio.create_task(report())
    await pool.main()
asyncio.run(runner())
