// Header building, SHA-256 and target maths vs vectors produced by xcoin-pool.py itself.
#include <fstream>
#include <sstream>
#include "../src/json.h"
#include "../src/work.h"
static int fails = 0;
#define CHECK(c, ...) do{ if(!(c)){ fails++; printf("FAIL: "); printf(__VA_ARGS__); printf("\n"); } }while(0)
int main(int argc, char** argv) {
    std::ifstream f(argc > 1 ? argv[1] : "pool_vectors.json"); std::stringstream ss; ss << f.rdbuf();
    JVal root; if (!JParser::parse(ss.str(), root)) { printf("json parse failed\n"); return 1; }
    for (auto& s : root.get("sha")->a) {
        std::vector<uint8_t> in; from_hex(s.get("in")->s, in);
        auto o = sha::sha256(in.data(), in.size());
        CHECK(to_hex(o.data(), 32) == s.get("out")->s, "sha256 len %zu", in.size());
    }
    int n = 0;
    for (auto& v : root.get("jobs")->a) {
        auto& p = v.get("params")->a;
        Job j; j.id = p[0].s; j.prevhash = p[1].s; j.cb1 = p[2].s; j.cb2 = p[3].s;
        for (auto& b : p[4].a) j.branches.push_back(b.s);
        j.version = p[5].s; j.nbits = p[6].s; j.ntime = p[7].s; j.clean = p[8].b;
        std::vector<uint8_t> h;
        CHECK(build_header76(j, v.get("en1")->s, v.get("en2")->s, h), "build");
        uint32_t nonce = (uint32_t)v.get("nonce")->n;
        char ns[9]; snprintf(ns, 9, "%08x", nonce);              // what we submit
        uint32_t back; hex_u32(ns, back);                         // what the pool parses
        put_le32(h, back);
        CHECK(to_hex(h.data(), h.size()) == v.get("header80")->s, "header80 job %s", j.id.c_str());
        uint32_t bits; hex_u32(j.nbits, bits);
        CHECK(u256_hex(bits_to_target(bits)) == v.get("bits_target")->s, "bits_to_target %s", j.nbits.c_str());
        n++;
    }
    for (auto& d : root.get("diffs")->a) {
        auto t = diff_to_target(d.get("d")->n);
        CHECK(u256_hex(t) == d.get("target")->s, "diff_to_target(%g): %s vs %s", d.get("d")->n, u256_hex(t).c_str(), d.get("target")->s.c_str());
    }
    // JSON robustness: malformed / hostile input must fail cleanly
    JVal x; CHECK(!JParser::parse("{\"a\":[1,2", x), "truncated");
    CHECK(!JParser::parse(std::string(500, '['), x), "deep nesting");
    CHECK(JParser::parse("{\"id\":3,\"result\":true,\"error\":null}", x) && x.get("result")->b, "simple");
    printf(fails ? "%d FAILURES\n" : "ALL WORK TESTS PASSED (%d headers, sha, targets, json)\n", fails ? fails : n);
    return fails ? 1 : 0;
}
