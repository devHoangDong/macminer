// powcheck: stdin lines of 80-byte header hex -> node-style PoW hex (big-endian), mainnet sizing.
// Stands in for the node's getmetaldagpowhash RPC in the mock-pool end-to-end test.
#include <iostream>
#include <string>
#include "../src/metaldag_light.h"
#include "../src/work.h"
int main() {
    auto P = mdl::mainnet_params();
    std::vector<mdl::Item> cache; uint64_t cur = ~0ULL; mdl::EpochSizing sz{};
    std::string line;
    while (std::getline(std::cin, line)) {
        std::vector<uint8_t> h; if (!from_hex(line, h) || h.size() != 80) { std::cout << "ERR\n" << std::flush; continue; }
        uint32_t ntime = mdl::ReadLE32(h.data() + 68);
        auto s = mdl::sizing(ntime, P);
        if (s.epoch != cur) { sz = s; cache = mdl::mkcache(s.cache_size, mdl::seed_for_epoch(s.epoch).data()); cur = s.epoch; }
        uint8_t out[32]; mdl::pow_hash(h.data(), sz.full_size, cache, out);
        std::cout << u256_hex(from_le_bytes(out)) << "\n" << std::flush;
    }
}
