// CPU cross-check: hashcore.h (GPU code path) and metaldag_light.h (miner's verifier)
// against the xCoin node's own consensus code, extracted verbatim from metaldag.cpp.
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <array>
#include <vector>
#include <map>
#include <memory>
#include <mutex>
#include <random>
#include <algorithm>
// minimal stand-ins for the node headers the extract needs
static inline uint32_t ReadLE32(const unsigned char* p){ return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24); }
static inline void WriteLE32(unsigned char* p, uint32_t v){ p[0]=v; p[1]=v>>8; p[2]=v>>16; p[3]=v>>24; }
namespace metaldag {
static constexpr uint32_t HASH_BYTES = 64, MIX_BYTES = 128, WORD_BYTES = 4;
static constexpr uint32_t DATASET_PARENTS = 256, CACHE_ROUNDS = 3, ACCESSES = 64;
static constexpr size_t METALDAG_CACHE_ENTRIES = 6;
}
#define namespace_metaldag_open
#include "node_metaldag_extract.inc"
} // close namespace metaldag opened by the extract

#include "../src/hashcore.h"
#include "../src/metaldag_light.h"

static int fails = 0;
#define CHECK(c, ...) do{ if(!(c)){ fails++; printf("FAIL: "); printf(__VA_ARGS__); printf("\n"); } }while(0)

// Emulates the production CUDA kernel's 8-lane shuffled hashimoto (see kernels.cuh):
// lane t owns mix words 4t..4t+3 and loads uint4 #t of each 128-byte DAG pair.
static void hashimoto_shuffled_emu(const uint32_t* dag, uint32_t pairs, const uint32_t hh[8],
                                   const uint32_t nonces[8], uint32_t out[8][8]) {
    uint32_t s[8][16];
    for (int l = 0; l < 8; l++) { uint32_t in10[10]; for (int i=0;i<8;i++) in10[i]=hh[i]; in10[8]=nonces[l]; in10[9]=0; keccak512_40(in10, s[l]); }
    uint32_t cm[8][8];
    for (int h = 0; h < 8; h++) {
        uint32_t mix[8][4]; uint32_t init0 = s[h][0];
        for (int l = 0; l < 8; l++) for (int e = 0; e < 4; e++) mix[l][e] = s[h][(4*l+e) % 16];
        for (uint32_t a = 0; a < 64; a += 4) {
            int t = (a >> 2) & 7;
            for (uint32_t b = 0; b < 4; b++) {
                uint32_t off[8]; for (int l = 0; l < 8; l++) off[l] = fnv(init0 ^ (a+b), mix[l][b]) % pairs;
                uint32_t o = off[t];
                for (int l = 0; l < 8; l++) for (int e = 0; e < 4; e++) mix[l][e] = fnv(mix[l][e], dag[(uint64_t)o*32 + l*4 + e]);
            }
        }
        for (int l = 0; l < 8; l++) cm[h][l] = fnv(fnv(fnv(mix[l][0],mix[l][1]),mix[l][2]),mix[l][3]);
    }
    for (int l = 0; l < 8; l++) { uint32_t fin[24]; for(int i=0;i<16;i++) fin[i]=s[l][i]; for(int i=0;i<8;i++) fin[16+i]=cm[l][i]; keccak256_96(fin, out[l]); }
}

static std::vector<uint32_t> cache_words(const std::vector<mdl::Item>& c) {
    std::vector<uint32_t> w(c.size()*16);
    for (size_t i=0;i<c.size();i++) for(int k=0;k<16;k++) w[i*16+k] = mdl::ReadLE32(c[i].data()+4*k);
    return w;
}

int main() {
    std::mt19937_64 rng(12345);
    // 1) keccak: word versions vs node byte version, and known vectors
    {
        uint8_t h[32]; metaldag::keccak256((const uint8_t*)"",0,h);
        char hex[65]; for(int i=0;i<32;i++) sprintf(hex+2*i,"%02x",h[i]);
        CHECK(!strcmp(hex,"c5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470"), "keccak256('') = %s", hex);
        for (int t=0;t<200;t++){
            uint8_t b[96]; for(auto&x:b) x=rng();
            uint32_t w[24]; for(int i=0;i<24;i++) w[i]=ReadLE32(b+4*i);
            uint8_t r1[64]; uint32_t r2[16];
            metaldag::keccak512(b,40,r1); keccak512_40(w,r2); CHECK(!memcmp(r1,r2,64),"keccak512_40");
            metaldag::keccak512(b,64,r1); keccak512_64(w,r2); CHECK(!memcmp(r1,r2,64),"keccak512_64");
            metaldag::keccak256(b,96,r1); keccak256_96(w,r2); CHECK(!memcmp(r1,r2,32),"keccak256_96");
        }
        printf("[ok] keccak word forms == node keccak (600 random inputs)\n");
    }
    // 2) sizing + seed vs node formulas at mainnet params
    {
        auto P = mdl::mainnet_params();
        auto e0 = mdl::sizing(1790380800u + 3600, P);
        printf("     mainnet epoch %llu: cache %llu B, full %llu B (%.3f GiB)\n",(unsigned long long)e0.epoch,(unsigned long long)e0.cache_size,(unsigned long long)e0.full_size, e0.full_size/1073741824.0);
        CHECK(e0.epoch==0, "epoch0");
        CHECK(e0.full_size == metaldag::largest_prime_sized(4ULL<<30, 128), "full size");
        CHECK(e0.cache_size == metaldag::largest_prime_sized((4ULL<<30)/128, 64), "cache size");
        auto e1 = mdl::sizing(1790380800u + 14*24*3600, P); CHECK(e1.epoch==1, "epoch1");
        CHECK(!memcmp(mdl::seed_for_epoch(3).data(), metaldag::seed_for_epoch(3), 32), "seed epoch 3");
        printf("[ok] epoch sizing + seeds\n");
    }
    // 3) regtest-sized full DAG: build with hashcore dag_item, compare to node items; hashimoto
    //    full (one-thread) and shuffled-emulation vs node light hashimoto, many nonces.
    {
        auto P = mdl::regtest_params();
        auto e = mdl::sizing((uint32_t)P.base_time, P);
        auto seed = mdl::seed_for_epoch(e.epoch);
        auto cache_node = metaldag::mkcache(e.cache_size, seed.data());
        auto cache_mine = mdl::mkcache(e.cache_size, seed.data());
        CHECK(cache_node == cache_mine, "mkcache");
        auto cw = cache_words(cache_mine);
        uint32_t n = (uint32_t)cache_mine.size();
        uint64_t items = e.full_size / 64, pairs = e.full_size / 128;
        std::vector<uint32_t> dag(items*16);
        for (uint64_t i=0;i<items;i++) dag_item(cw.data(), n, i, &dag[i*16]);
        int bad=0; for (uint64_t i=0;i<items;i+=97){ auto it=metaldag::calc_dataset_item(cache_node,i); if(memcmp(it.data(),&dag[i*16],64)) bad++; }
        CHECK(bad==0, "dag items mismatch %d", bad);
        printf("[ok] regtest DAG (%llu items) == node calc_dataset_item\n",(unsigned long long)items);
        for (int t=0;t<40;t++){
            uint8_t hhb[32]; for(auto&x:hhb) x=rng(); uint32_t hh[8]; for(int i=0;i<8;i++) hh[i]=ReadLE32(hhb+4*i);
            uint32_t nonces[8]; for(auto&x:nonces) x=(uint32_t)rng();
            uint32_t shuf[8][8]; hashimoto_shuffled_emu(dag.data(), (uint32_t)pairs, hh, nonces, shuf);
            for (int l=0;l<8;l++){
                uint8_t rn[32]; metaldag::hashimoto_light(e.full_size, cache_node, hhb, nonces[l], rn);
                uint32_t rf[8]; hashimoto_full(dag.data(), pairs, hh, nonces[l], rf);
                CHECK(!memcmp(rn,rf,32), "hashimoto_full vs node");
                CHECK(!memcmp(rn,shuf[l],32), "shuffled vs node");
                uint8_t rl[32]; mdl::hashimoto_light(e.full_size, cache_mine, hhb, nonces[l], rl);
                CHECK(!memcmp(rn,rl,32), "miner light vs node");
            }
        }
        printf("[ok] hashimoto: one-thread, 8-lane shuffled emulation and miner verifier == node (320 nonces)\n");
    }
    // 4) real mainnet epoch-0 cache: DAG items from hashcore vs node, and miner light vs node light
    {
        auto P = mdl::mainnet_params();
        auto e = mdl::sizing(1790380800u + 100, P);
        auto seed = mdl::seed_for_epoch(e.epoch);
        printf("     building mainnet epoch-0 cache (%.1f MiB) twice...\n", e.cache_size/1048576.0);
        auto cache_node = metaldag::mkcache(e.cache_size, seed.data());
        auto cache_mine = mdl::mkcache(e.cache_size, seed.data());
        CHECK(cache_node == cache_mine, "mainnet mkcache");
        auto cw = cache_words(cache_mine); uint32_t n=(uint32_t)cache_mine.size();
        uint64_t items = e.full_size/64;
        for (int t=0;t<64;t++){ uint64_t i = rng() % items; uint32_t w[16]; dag_item(cw.data(), n, i, w);
            auto it = metaldag::calc_dataset_item(cache_node, i); CHECK(!memcmp(it.data(), w, 64), "mainnet item %llu",(unsigned long long)i); }
        for (int t=0;t<8;t++){ uint8_t hh[32]; for(auto&x:hh) x=rng(); uint32_t nonce=(uint32_t)rng();
            uint8_t a[32], b[32]; metaldag::hashimoto_light(e.full_size, cache_node, hh, nonce, a); mdl::hashimoto_light(e.full_size, cache_mine, hh, nonce, b);
            CHECK(!memcmp(a,b,32), "mainnet light"); }
        // record a vector for the GPU self-test
        uint8_t hh[32]; for(int i=0;i<32;i++) hh[i]=(uint8_t)i; uint8_t r[32];
        metaldag::hashimoto_light(e.full_size, cache_node, hh, 0x12345678u, r);
        printf("     vector: epoch0 hh=00..1f nonce=0x12345678 -> ");
        for(int i=31;i>=0;i--) printf("%02x", r[i]); printf("\n");
        printf("[ok] mainnet epoch-0: 64 random DAG items + 8 light hashes == node\n");
    }
    printf(fails ? "\n%d FAILURES\n" : "\nALL CORE TESTS PASSED\n", fails);
    return fails ? 1 : 0;
}
