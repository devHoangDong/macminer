# Generates job/header/target vectors with the pool's own byte logic
# (xcoin-pool.py: Jobs.refresh, Session.notify, Session.validate, diff_to_target, bits_to_target).
import hashlib, json, os, random, sys
sys.path.insert(0, "/tmp/xCoin/xcoin-pool")
import importlib.util
spec = importlib.util.spec_from_file_location("pool", "/tmp/xCoin/xcoin-pool/xcoin-pool.py")
pool = importlib.util.module_from_spec(spec); spec.loader.exec_module(pool)

def dsha256(b): return hashlib.sha256(hashlib.sha256(b).digest()).digest()
random.seed(7)
vecs = []
for t in range(50):
    prev_le = os.urandom(32)
    nbr = random.randint(0, 6)
    branch_le = [os.urandom(32) for _ in range(nbr)]
    p1 = os.urandom(random.randint(40, 120)); p2 = os.urandom(random.randint(20, 90))
    en1 = os.urandom(4); en2 = os.urandom(4)
    version = random.getrandbits(32) & 0x0fffffff
    bits = random.choice(["1d00ffff", "1e0ffff0", "207fffff", "1c05a3f4", "1f00ffff"])
    curtime = random.randint(1790380800, 1800000000)
    prev_stratum = b"".join(prev_le[i:i+4][::-1] for i in range(0, 32, 4)).hex()   # notify()
    params = ["%x" % t, prev_stratum, p1.hex(), p2.hex(), [b.hex() for b in branch_le],
              f"{version:08x}", bits, f"{curtime:08x}", True]
    # validate(): ntime/nonce parsed from the submit strings the miner sends
    nonce = random.getrandbits(32)
    cb = p1 + en1 + en2 + p2
    root = dsha256(cb)
    for sib in branch_le: root = dsha256(root + sib)
    header = (version.to_bytes(4,"little") + prev_le + root + int(f"{curtime:08x}",16).to_bytes(4,"little")
              + int(bits,16).to_bytes(4,"little") + int("%08x" % nonce, 16).to_bytes(4,"little"))
    vecs.append({"params": params, "en1": en1.hex(), "en2": en2.hex(), "nonce": nonce,
                 "header80": header.hex(), "bits_target": "%064x" % pool.bits_to_target(bits)})
diffs = [0.05, 0.001, 1, 3.7, 0.000001, 1000000, 12345.678, 0.3333333, 1e-9, 2**-20]
dvec = [{"d": d, "target": "%064x" % min(pool.diff_to_target(d), 2**256-1)} for d in diffs]
shav = [{"in": os.urandom(n).hex()} for n in (0, 1, 55, 56, 63, 64, 65, 119, 200)]
for s in shav: s["out"] = hashlib.sha256(bytes.fromhex(s["in"])).hexdigest()
json.dump({"jobs": vecs, "diffs": dvec, "sha": shav}, open(sys.argv[1], "w"))
print("wrote", len(vecs), "job vectors,", len(dvec), "diff vectors")
