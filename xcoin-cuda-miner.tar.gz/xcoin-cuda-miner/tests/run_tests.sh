#!/usr/bin/env bash
# CPU-side verification (no GPU needed). Needs a C++17 compiler; the pool vectors need
# a clone of github.com/SystemThreat/xCoin at $XCOIN (default /tmp/xCoin) to regenerate.
set -euo pipefail
cd "$(dirname "$0")"
XCOIN=${XCOIN:-/tmp/xCoin}
if [[ -f $XCOIN/src/metaldag/metaldag.cpp ]]; then
  awk '/^namespace metaldag \{/{f=1} f{print} /^\} \/\/ anonymous namespace/{exit}' "$XCOIN/src/metaldag/metaldag.cpp" > node_metaldag_extract.inc
  python3 gen_pool_vectors.py pool_vectors.json
fi
g++ -O2 -std=c++17 -o test_core test_core.cpp && ./test_core
g++ -O2 -std=c++17 -o test_work test_work.cpp && ./test_work pool_vectors.json
g++ -O2 -std=c++17 -o powcheck powcheck.cpp && echo "powcheck built (used by mock_pool.py)"
