// common.h — shared helpers usable from host C++ and CUDA device code.
#pragma once
#include <cstdint>
#include <cstddef>

#ifdef __CUDACC__
  #define HD __host__ __device__ __forceinline__
#else
  #define HD inline
#endif

#if defined(__CUDA_ARCH__)
  #define UNROLL _Pragma("unroll")
#else
  #define UNROLL
#endif
