// hashcore.h — MetalDAG (Ethash-family) primitives in 32-bit word form.
// Mirrors the Metal kernels in NerdMiner (MetalDAGShader.swift) and the node's
// consensus code (src/metaldag/metaldag.cpp). Compiles for host and device so the
// exact same code is unit-tested on the CPU against the node's implementation.
#pragma once
#include "common.h"

HD uint64_t rotl64(uint64_t x, int n) { return (x << n) | (x >> (64 - n)); }

// Keccak-f[1600], original Keccak (Ethash), not NIST SHA-3.
HD void keccakf(uint64_t st[25]) {
    const uint64_t RC[24] = {
        0x0000000000000001ULL,0x0000000000008082ULL,0x800000000000808aULL,0x8000000080008000ULL,
        0x000000000000808bULL,0x0000000080000001ULL,0x8000000080008081ULL,0x8000000000008009ULL,
        0x000000000000008aULL,0x0000000000000088ULL,0x0000000080008009ULL,0x000000008000000aULL,
        0x000000008000808bULL,0x800000000000008bULL,0x8000000000008089ULL,0x8000000000008003ULL,
        0x8000000000008002ULL,0x8000000000000080ULL,0x000000000000800aULL,0x800000008000000aULL,
        0x8000000080008081ULL,0x8000000000008080ULL,0x0000000080000001ULL,0x8000000080008008ULL};
    const int ROT[24] = {1,3,6,10,15,21,28,36,45,55,2,14,27,41,56,8,25,43,62,18,39,61,20,44};
    const int PI[24]  = {10,7,11,17,18,3,5,16,8,21,24,4,15,23,19,13,12,2,20,14,22,9,6,1};
    UNROLL
    for (int r = 0; r < 24; r++) {
        uint64_t bc[5], t;
        UNROLL for (int i = 0; i < 5; i++) bc[i] = st[i] ^ st[i+5] ^ st[i+10] ^ st[i+15] ^ st[i+20];
        UNROLL for (int i = 0; i < 5; i++) {
            t = bc[(i+4)%5] ^ rotl64(bc[(i+1)%5], 1);
            UNROLL for (int j = 0; j < 25; j += 5) st[j+i] ^= t;
        }
        t = st[1];
        UNROLL for (int i = 0; i < 24; i++) { int j = PI[i]; uint64_t tmp = st[j]; st[j] = rotl64(t, ROT[i]); t = tmp; }
        UNROLL for (int j = 0; j < 25; j += 5) {
            uint64_t b0=st[j], b1=st[j+1], b2=st[j+2], b3=st[j+3], b4=st[j+4];
            st[j]   ^= (~b1) & b2; st[j+1] ^= (~b2) & b3; st[j+2] ^= (~b3) & b4;
            st[j+3] ^= (~b4) & b0; st[j+4] ^= (~b0) & b1;
        }
        st[0] ^= RC[r];
    }
}

// keccak512 of a 40-byte input (header hash || 64-bit LE nonce).
HD void keccak512_40(const uint32_t in10[10], uint32_t out16[16]) {
    uint64_t st[25];
    UNROLL for (int i = 0; i < 25; i++) st[i] = 0;
    UNROLL for (int k = 0; k < 5; k++) st[k] = (uint64_t)in10[2*k] | ((uint64_t)in10[2*k+1] << 32);
    st[5] ^= 0x01ULL; st[8] ^= 0x8000000000000000ULL;
    keccakf(st);
    UNROLL for (int k = 0; k < 8; k++) { out16[2*k] = (uint32_t)st[k]; out16[2*k+1] = (uint32_t)(st[k] >> 32); }
}
// keccak512 of a 64-byte input. in and out may alias.
HD void keccak512_64(const uint32_t in16[16], uint32_t out16[16]) {
    uint64_t st[25];
    UNROLL for (int i = 0; i < 25; i++) st[i] = 0;
    UNROLL for (int k = 0; k < 8; k++) st[k] = (uint64_t)in16[2*k] | ((uint64_t)in16[2*k+1] << 32);
    st[8] ^= 0x8000000000000001ULL;
    keccakf(st);
    UNROLL for (int k = 0; k < 8; k++) { out16[2*k] = (uint32_t)st[k]; out16[2*k+1] = (uint32_t)(st[k] >> 32); }
}
// keccak256 of a 96-byte input (s || cmix).
HD void keccak256_96(const uint32_t in24[24], uint32_t out8[8]) {
    uint64_t st[25];
    UNROLL for (int i = 0; i < 25; i++) st[i] = 0;
    UNROLL for (int k = 0; k < 12; k++) st[k] = (uint64_t)in24[2*k] | ((uint64_t)in24[2*k+1] << 32);
    st[12] ^= 0x01ULL; st[16] ^= 0x8000000000000000ULL;
    keccakf(st);
    UNROLL for (int k = 0; k < 4; k++) { out8[2*k] = (uint32_t)st[k]; out8[2*k+1] = (uint32_t)(st[k] >> 32); }
}

HD uint32_t fnv(uint32_t a, uint32_t b) { return (a * 0x01000193u) ^ b; }

// One 64-byte DAG item (16 LE words) from the light cache (n items of 16 words).
HD void dag_item(const uint32_t* cache, uint32_t n, uint64_t i, uint32_t out16[16]) {
    const uint32_t i32 = (uint32_t)i;
    uint32_t mix[16];
    const uint64_t b0 = (i % n) * 16;
    UNROLL for (int k = 0; k < 16; k++) mix[k] = cache[b0 + k];
    mix[0] ^= i32;
    keccak512_64(mix, mix);
    for (uint32_t j0 = 0; j0 < 256; j0 += 16) {          // inner unroll keeps mix[] in registers
        UNROLL for (uint32_t jj = 0; jj < 16; jj++) {
            const uint32_t ci = fnv(i32 ^ (j0 + jj), mix[jj]);
            const uint64_t base = (uint64_t)(ci % n) * 16;
            UNROLL for (int k = 0; k < 16; k++) mix[k] = fnv(mix[k], cache[base + k]);
        }
    }
    keccak512_64(mix, out16);
}

// Plain one-thread hashimoto over a full DAG (words). Reference for tests; the GPU
// production kernel computes the same thing with 8 cooperating threads.
// pairs = full_size / 128. res8: little-endian words, res8[7] = most significant.
HD void hashimoto_full(const uint32_t* dag, uint64_t pairs, const uint32_t hh[8], uint32_t nonce, uint32_t res8[8]) {
    uint32_t in10[10];
    UNROLL for (int i = 0; i < 8; i++) in10[i] = hh[i];
    in10[8] = nonce; in10[9] = 0;
    uint32_t s[16]; keccak512_40(in10, s);
    uint32_t mix[32];
    UNROLL for (int i = 0; i < 32; i++) mix[i] = s[i % 16];
    for (uint32_t i = 0; i < 64; i++) {
        const uint64_t p = (uint64_t)(fnv(i ^ s[0], mix[i % 32]) % pairs);
        const uint32_t* d = dag + p * 32;
        UNROLL for (int k = 0; k < 32; k++) mix[k] = fnv(mix[k], d[k]);
    }
    uint32_t fin[24];
    UNROLL for (int i = 0; i < 16; i++) fin[i] = s[i];
    UNROLL for (int i = 0; i < 32; i += 4) fin[16 + i/4] = fnv(fnv(fnv(mix[i], mix[i+1]), mix[i+2]), mix[i+3]);
    keccak256_96(fin, res8);
}
