// metaldag_light.h — host-only port of the xCoin node's consensus MetalDAG code
// (src/metaldag/metaldag.cpp at github.com/SystemThreat/xCoin), byte-oriented and
// independent of hashcore.h. The miner uses it (a) to build the per-epoch light
// cache, and (b) to re-verify every GPU result exactly as the pool's node will
// (getmetaldagpowhash) before submitting. Tests compare it with hashcore.h.
#pragma once
#include <array>
#include <cstdint>
#include <cstring>
#include <vector>

namespace mdl {

static const uint32_t HASH_BYTES = 64, MIX_BYTES = 128, WORD_BYTES = 4;
static const uint32_t DATASET_PARENTS = 256, CACHE_ROUNDS = 3, ACCESSES = 64;

inline uint32_t ReadLE32(const uint8_t* p) { return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24); }
inline void WriteLE32(uint8_t* p, uint32_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); p[2] = (uint8_t)(v >> 16); p[3] = (uint8_t)(v >> 24); }

static const uint64_t KECCAK_RC[24] = {
 0x0000000000000001ULL,0x0000000000008082ULL,0x800000000000808aULL,0x8000000080008000ULL,
 0x000000000000808bULL,0x0000000080000001ULL,0x8000000080008081ULL,0x8000000000008009ULL,
 0x000000000000008aULL,0x0000000000000088ULL,0x0000000080008009ULL,0x000000008000000aULL,
 0x000000008000808bULL,0x800000000000008bULL,0x8000000000008089ULL,0x8000000000008003ULL,
 0x8000000000008002ULL,0x8000000000000080ULL,0x000000000000800aULL,0x800000008000000aULL,
 0x8000000080008081ULL,0x8000000000008080ULL,0x0000000080000001ULL,0x8000000080008008ULL};
static const int KECCAK_ROT[24]={1,3,6,10,15,21,28,36,45,55,2,14,27,41,56,8,25,43,62,18,39,61,20,44};
static const int KECCAK_PI[24]={10,7,11,17,18,3,5,16,8,21,24,4,15,23,19,13,12,2,20,14,22,9,6,1};
inline uint64_t rol64(uint64_t x,int n){ return (x<<n)|(x>>(64-n)); }
inline void keccakf(uint64_t st[25]){
    for(int r=0;r<24;r++){
        uint64_t bc[5],t;
        for(int i=0;i<5;i++) bc[i]=st[i]^st[i+5]^st[i+10]^st[i+15]^st[i+20];
        for(int i=0;i<5;i++){ t=bc[(i+4)%5]^rol64(bc[(i+1)%5],1); for(int j=0;j<25;j+=5) st[j+i]^=t; }
        t=st[1];
        for(int i=0;i<24;i++){ int j=KECCAK_PI[i]; uint64_t tmp=st[j]; st[j]=rol64(t,KECCAK_ROT[i]); t=tmp; }
        for(int j=0;j<25;j+=5){ for(int i=0;i<5;i++) bc[i]=st[j+i]; for(int i=0;i<5;i++) st[j+i]^=(~bc[(i+1)%5])&bc[(i+2)%5]; }
        st[0]^=KECCAK_RC[r];
    }
}
inline void keccak(int rate_bytes, const uint8_t* in, size_t inlen, uint8_t* out, size_t outlen){
    uint64_t st[25]; std::memset(st,0,sizeof st);
    size_t pt=0;
    for(size_t i=0;i<inlen;i++){
        st[pt>>3] ^= (uint64_t)in[i] << (8*(pt&7));
        if(++pt==(size_t)rate_bytes){ keccakf(st); pt=0; }
    }
    st[pt>>3] ^= (uint64_t)0x01 << (8*(pt&7));
    st[(size_t)(rate_bytes-1)>>3] ^= (uint64_t)0x80 << (8*((size_t)(rate_bytes-1)&7));
    keccakf(st);
    for(size_t i=0;i<outlen;i++) out[i] = (uint8_t)(st[i>>3] >> (8*(i&7)));
}
inline void keccak256(const uint8_t* in,size_t n,uint8_t out[32]){ keccak(136,in,n,out,32); }
inline void keccak512(const uint8_t* in,size_t n,uint8_t out[64]){ keccak(72 ,in,n,out,64); }
inline uint32_t fnv(uint32_t a,uint32_t b){ return (a*0x01000193u) ^ b; }

using Item = std::array<uint8_t,64>;
inline uint32_t rd32(const Item& it,int k){ return ReadLE32(it.data()+4*k); }
inline void     wr32(Item& it,int k,uint32_t v){ WriteLE32(it.data()+4*k, v); }

inline std::vector<Item> mkcache(size_t cache_size, const uint8_t seed[32]){
    size_t n = cache_size / HASH_BYTES;
    std::vector<Item> o(n);
    keccak512(seed,32,o[0].data());
    for(size_t i=1;i<n;i++) keccak512(o[i-1].data(),64,o[i].data());
    for(uint32_t r=0;r<CACHE_ROUNDS;r++){
        for(size_t i=0;i<n;i++){
            uint32_t v = rd32(o[i],0) % (uint32_t)n;
            Item tmp;
            for(int k=0;k<16;k++) wr32(tmp,k, rd32(o[(i+n-1)%n],k) ^ rd32(o[v],k));
            keccak512(tmp.data(),64,o[i].data());
        }
    }
    return o;
}

inline Item calc_dataset_item(const std::vector<Item>& cache, uint64_t i){
    size_t n = cache.size();
    const uint32_t r = HASH_BYTES / WORD_BYTES;
    const uint32_t i32 = static_cast<uint32_t>(i);
    Item mix = cache[i % n];
    wr32(mix,0, rd32(mix,0) ^ i32);
    keccak512(mix.data(),64,mix.data());
    for(uint32_t j=0;j<DATASET_PARENTS;j++){
        uint32_t cache_index = fnv(i32 ^ j, rd32(mix, j % r));
        const Item& c = cache[cache_index % n];
        for(int k=0;k<16;k++) wr32(mix,k, fnv(rd32(mix,k), rd32(c,k)));
    }
    keccak512(mix.data(),64,mix.data());
    return mix;
}

inline void hashimoto_light(uint64_t full_size, const std::vector<Item>& cache,
                            const uint8_t header[32], uint64_t nonce, uint8_t result[32]){
    const uint64_t n = full_size / HASH_BYTES;
    const uint32_t w_words = MIX_BYTES / WORD_BYTES;
    const uint32_t mixhashes = MIX_BYTES / HASH_BYTES;
    uint8_t s_in[40];
    std::memcpy(s_in,header,32);
    for(int k=0;k<8;k++) s_in[32+k] = (uint8_t)(nonce >> (8*k));
    uint8_t s[64]; keccak512(s_in,40,s);
    auto sw = [&](uint32_t idx){ return ReadLE32(s + 4*idx); };
    uint32_t mix[32];
    for(uint32_t i=0;i<w_words;i++) mix[i] = sw(i % (HASH_BYTES/WORD_BYTES));
    for(uint32_t i=0;i<ACCESSES;i++){
        const uint64_t p = uint64_t{fnv(i ^ sw(0), mix[i % w_words])} % (n / mixhashes) * mixhashes;
        uint32_t newdata[32];
        for(uint32_t j=0;j<mixhashes;j++){
            Item di = calc_dataset_item(cache, p + j);
            for(int k=0;k<16;k++) newdata[j*16+k] = rd32(di,k);
        }
        for(uint32_t k=0;k<w_words;k++) mix[k] = fnv(mix[k], newdata[k]);
    }
    uint32_t cmix[8];
    for(uint32_t i=0;i<w_words;i+=4)
        cmix[i/4] = fnv(fnv(fnv(mix[i],mix[i+1]),mix[i+2]),mix[i+3]);
    uint8_t final_in[96]; std::memcpy(final_in,s,64);
    for(int i=0;i<8;i++) WriteLE32(final_in+64+4*i, cmix[i]);
    keccak256(final_in,96,result);
}

inline bool is_prime(uint64_t n){
    if(n<2) return false;
    if(n%2==0) return n==2;
    for(uint64_t i=3;i*i<=n;i+=2) if(n%i==0) return false;
    return true;
}
inline uint64_t largest_prime_sized(uint64_t target, uint32_t unit){
    uint64_t items = target / unit;
    if(items < 2) items = 2;
    while(items > 2 && !is_prime(items)) items--;
    return items * (uint64_t)unit;
}

struct Params {
    uint64_t base_time;      // genesis time (mainnet 1790380800, chainparams FINAL_GENESIS_TIME)
    uint64_t epoch_seconds;  // 14 days
    uint64_t dag_init;       // 4 GiB
    uint64_t dag_growth;     // 128 MiB / epoch
    uint32_t cache_divisor;  // 128
};
inline Params mainnet_params(){ return Params{1790380800ULL, 14ULL*24*3600, 4ULL<<30, 128ULL<<20, 128}; }
inline Params regtest_params(){ return Params{1296688602ULL, 1000ULL, 1ULL<<20, 0ULL, 128}; }

struct EpochSizing { uint64_t epoch, cache_size, full_size; };
inline EpochSizing sizing(uint32_t nTime, const Params& p){
    EpochSizing e;
    uint64_t rel = (uint64_t)nTime > p.base_time ? (uint64_t)nTime - p.base_time : 0;
    e.epoch = rel / p.epoch_seconds;
    uint64_t raw_full  = p.dag_init + p.dag_growth * e.epoch;
    uint64_t raw_cache = raw_full / p.cache_divisor;
    if(raw_full  < MIX_BYTES*2)  raw_full  = MIX_BYTES*2;
    if(raw_cache < HASH_BYTES*2) raw_cache = HASH_BYTES*2;
    e.full_size  = largest_prime_sized(raw_full,  MIX_BYTES);
    e.cache_size = largest_prime_sized(raw_cache, HASH_BYTES);
    return e;
}
inline std::array<uint8_t,32> seed_for_epoch(uint64_t epoch){
    std::array<uint8_t,32> s; s.fill(0);
    for(uint64_t e=0;e<epoch;e++){ std::array<uint8_t,32> nx; keccak256(s.data(),32,nx.data()); s=nx; }
    return s;
}

// PoW of an 80-byte serialized header, as the node's PoWHash(): result bytes are the
// uint256 in little-endian order (byte 31 = most significant).
inline void pow_hash(const uint8_t header80[80], uint64_t full_size, const std::vector<Item>& cache, uint8_t out32[32]){
    uint8_t hh[32]; keccak256(header80, 76, hh);
    uint32_t nonce = ReadLE32(header80 + 76);
    hashimoto_light(full_size, cache, hh, (uint64_t)nonce, out32);
}

} // namespace mdl
