// xcoin-cuda-miner — MetalDAG (xCoin / XID) miner for NVIDIA GPUs.
// Independent CUDA port of the algorithm in github.com/SystemThreat/xCoin
// (src/metaldag/metaldag.cpp, miner/MetalDAGShader.swift). MIT License.
#include <cuda_runtime.h>
#include <signal.h>
#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstring>
#include <fstream>
#include <memory>
#include <random>
#include <sstream>
#include <thread>
#include "kernels.cuh"
#include "metaldag_light.h"
#include "stratum.h"

static const char* VERSION = "0.1.0";
static std::atomic<bool> g_stop{false};
static void on_signal(int) { g_stop = true; }

#define CU(call) do { cudaError_t e_ = (call); if (e_ != cudaSuccess) { logf("GPU%d CUDA error %s at %s:%d", dev, cudaGetErrorString(e_), __FILE__, __LINE__); return false; } } while (0)

// ───────────────────────── options ─────────────────────────
struct Options {
    std::vector<PoolAddr> pools;
    std::string address, worker = "rig", password = "x";
    std::vector<int> devices;
    int batch_log2 = 22;
    uint64_t base_time = 1790380800ULL;      // mainnet genesis (src/kernel/chainparams.cpp FINAL_GENESIS_TIME)
    std::string stats_file;
    bool benchmark = false, selftest_only = false, cpu_mine = false;
    int bench_seconds = 60;
};

static void usage() {
    printf("xcoin-cuda-miner %s — MetalDAG (xCoin XID) miner for NVIDIA GPUs\n\n"
           "Usage:\n"
           "  xcoin-cuda-miner -o HOST:PORT -u xpa1r...[.WORKER] [options]\n\n"
           "  -o, --pool HOST:PORT     stratum pool (repeat for failover)\n"
           "                           PPLNS Singapore 198.252.101.117:3336 | solo NY pool.xcoinminer.com:3335\n"
           "  -u, --user ADDR[.WORKER] payout address (xpa1r...), optional .worker\n"
           "  -w, --worker NAME        worker name (default: rig)\n"
           "  -p, --pass PASS          pool password (ignored by xcoin-pool)\n"
           "  -d, --devices 0,1,...    CUDA devices to use (default: all)\n"
           "      --batch N            nonces per kernel launch = 2^N (default 22)\n"
           "      --base UNIXTIME      MetalDAG epoch base (default mainnet genesis 1790380800)\n"
           "      --stats-file PATH    write JSON stats every 10 s (HiveOS h-stats.sh)\n"
           "      --benchmark [SEC]    build the DAG, self-test, then hash without a pool\n"
           "      --selftest           build the DAG, verify GPU against CPU, exit\n", VERSION);
}

static bool parse_args(int argc, char** argv, Options& o) {
    for (int i = 1; i < argc; i++) {
        std::string a = argv[i];
        auto next = [&](std::string& v) { if (i + 1 >= argc) return false; v = argv[++i]; return true; };
        std::string v;
        if (a == "-h" || a == "--help") { usage(); exit(0); }
        else if (a == "--version") { printf("xcoin-cuda-miner %s\n", VERSION); exit(0); }
        else if (a == "-o" || a == "--pool") {
            if (!next(v)) return false;
            if (v.rfind("stratum+tcp://", 0) == 0) v = v.substr(14);
            size_t c = v.rfind(':'); if (c == std::string::npos) return false;
            o.pools.push_back({v.substr(0, c), v.substr(c + 1)});
        }
        else if (a == "-u" || a == "--user") {
            if (!next(v)) return false;
            size_t d = v.find('.');
            if (d != std::string::npos) { o.address = v.substr(0, d); o.worker = v.substr(d + 1); } else o.address = v;
        }
        else if (a == "-w" || a == "--worker") { if (!next(o.worker)) return false; }
        else if (a == "-p" || a == "--pass") { if (!next(o.password)) return false; }
        else if (a == "-d" || a == "--devices") {
            if (!next(v)) return false;
            std::stringstream ss(v); std::string t; while (std::getline(ss, t, ',')) if (!t.empty()) o.devices.push_back(atoi(t.c_str()));
        }
        else if (a == "--batch") { if (!next(v)) return false; o.batch_log2 = std::max(16, std::min(28, atoi(v.c_str()))); }
        else if (a == "--base") { if (!next(v)) return false; o.base_time = strtoull(v.c_str(), nullptr, 10); }
        else if (a == "--stats-file") { if (!next(o.stats_file)) return false; }
        else if (a == "--benchmark") { o.benchmark = true; if (i + 1 < argc && argv[i+1][0] != '-') o.bench_seconds = atoi(argv[++i]); }
        else if (a == "--selftest") { o.selftest_only = true; }
        else if (a == "--cpu-mine") { o.cpu_mine = true; }          // hidden: protocol test without a GPU
        else if (a[0] != '-' && o.address.empty()) { o.address = a; }
        else { fprintf(stderr, "unknown option: %s\n", a.c_str()); return false; }
    }
    return true;
}

// bech32m check (BIP-350), as NerdMiner's isValidXcoinAddress: hrp xpa/txa, witness v3 ('r').
static bool valid_address(const std::string& addr_in) {
    std::string a = addr_in; for (auto& c : a) c = (char)tolower(c);
    size_t pos = a.rfind('1'); if (pos == std::string::npos || pos < 1 || pos + 7 > a.size()) return false;
    std::string hrp = a.substr(0, pos);
    if (hrp != "xpa" && hrp != "txa") return false;
    static const char* CH = "qpzry9x8gf2tvdw0s3jn54khce6mua7l";
    std::vector<int> v;
    for (char c : hrp) v.push_back(c >> 5);
    v.push_back(0);
    for (char c : hrp) v.push_back(c & 31);
    for (size_t i = pos + 1; i < a.size(); i++) { const char* p = strchr(CH, a[i]); if (!p) return false; v.push_back((int)(p - CH)); }
    if (v[hrp.size() * 2 + 1] != 3) return false;          // first data char = witness version 3 ('r')
    uint32_t chk = 1; const uint32_t G[5] = {0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3};
    for (int x : v) { uint32_t b = chk >> 25; chk = ((chk & 0x1ffffff) << 5) ^ (uint32_t)x; for (int i = 0; i < 5; i++) if ((b >> i) & 1) chk ^= G[i]; }
    return chk == 0x2bc830a3;
}

// ───────────────────────── epoch light caches (shared by all GPUs) ─────────────────────────
struct EpochData {
    mdl::EpochSizing sz;
    std::vector<mdl::Item> cache;
    std::vector<uint32_t> words;
};
static std::mutex g_epoch_m;
static std::map<uint64_t, std::shared_ptr<EpochData>> g_epochs;
static std::shared_ptr<EpochData> get_epoch(uint32_t ntime, const mdl::Params& P) {
    mdl::EpochSizing sz = mdl::sizing(ntime, P);
    std::lock_guard<std::mutex> lk(g_epoch_m);
    auto it = g_epochs.find(sz.epoch);
    if (it != g_epochs.end()) return it->second;
    logf("epoch %llu: building light cache (%.1f MiB) on CPU, DAG %.3f GiB ...", (unsigned long long)sz.epoch,
         sz.cache_size / 1048576.0, sz.full_size / 1073741824.0);
    auto t0 = std::chrono::steady_clock::now();
    auto ed = std::make_shared<EpochData>();
    ed->sz = sz;
    auto seed = mdl::seed_for_epoch(sz.epoch);
    ed->cache = mdl::mkcache(sz.cache_size, seed.data());
    ed->words.resize(ed->cache.size() * 16);
    for (size_t i = 0; i < ed->cache.size(); i++) for (int k = 0; k < 16; k++) ed->words[i*16 + k] = mdl::ReadLE32(ed->cache[i].data() + 4*k);
    logf("epoch %llu: light cache ready in %.1f s", (unsigned long long)sz.epoch,
         std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count());
    g_epochs[sz.epoch] = ed;
    while (g_epochs.size() > 2) g_epochs.erase(g_epochs.begin());
    return ed;
}

// ───────────────────────── per-GPU worker ─────────────────────────
struct GpuStats { std::atomic<uint64_t> hashes{0}; std::atomic<uint64_t> hw_errors{0}; std::atomic<bool> alive{false}; double hps = 0; std::string name; };

struct Gpu {
    int dev; GpuStats* st;
    uint4* dag = nullptr; uint32_t* cache_d = nullptr; MineOut* out_d = nullptr; uint32_t* dbg_d = nullptr;
    uint64_t epoch = ~0ULL; std::shared_ptr<EpochData> ed;

    bool build_dag(const std::shared_ptr<EpochData>& e) {
        if (dag) { cudaFree(dag); dag = nullptr; }
        if (cache_d) { cudaFree(cache_d); cache_d = nullptr; }
        size_t freeb = 0, totb = 0; cudaMemGetInfo(&freeb, &totb);
        if (freeb < e->sz.full_size + e->sz.cache_size + (64u << 20)) {
            logf("GPU%d: not enough memory for the %.2f GiB DAG (free %.2f GiB)", dev, e->sz.full_size / 1073741824.0, freeb / 1073741824.0);
            return false;
        }
        CU(cudaMalloc(&cache_d, e->sz.cache_size));
        CU(cudaMemcpy(cache_d, e->words.data(), e->sz.cache_size, cudaMemcpyHostToDevice));
        CU(cudaMalloc(&dag, e->sz.full_size));
        const uint64_t items = e->sz.full_size / 64;
        const uint32_t n = (uint32_t)(e->sz.cache_size / 64);
        const uint64_t chunk = 1ULL << 20;
        auto t0 = std::chrono::steady_clock::now();
        for (uint64_t s = 0; s < items && !g_stop; s += chunk) {
            uint64_t cnt = std::min(chunk, items - s);
            build_dag_kernel<<<(unsigned)((cnt + 255) / 256), 256>>>(cache_d, n, dag, s, items);
            CU(cudaGetLastError());
            CU(cudaDeviceSynchronize());
        }
        cudaFree(cache_d); cache_d = nullptr;     // the miner only needs the DAG; CPU keeps the light cache
        logf("GPU%d: DAG epoch %llu built in %.1f s", dev, (unsigned long long)e->sz.epoch,
             std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count());
        ed = e; epoch = e->sz.epoch;
        return selftest();
    }

    // Compare GPU output with the node-equivalent CPU code before mining a single nonce.
    bool selftest() {
        std::mt19937_64 rng(dev * 7919 + epoch);
        const uint64_t items = ed->sz.full_size / 64;
        for (int t = 0; t < 16; t++) {
            uint64_t i = (t == 0) ? 0 : (t == 1) ? items - 1 : rng() % items;
            uint8_t gpu_item[64];
            CU(cudaMemcpy(gpu_item, (const uint8_t*)dag + i * 64, 64, cudaMemcpyDeviceToHost));
            auto cpu = mdl::calc_dataset_item(ed->cache, i);
            if (memcmp(gpu_item, cpu.data(), 64)) { logf("GPU%d SELFTEST FAILED: DAG item %llu differs from CPU", dev, (unsigned long long)i); return false; }
        }
        uint8_t hhb[32]; for (int i = 0; i < 32; i++) hhb[i] = (uint8_t)i;
        uint32_t hh[8]; for (int i = 0; i < 8; i++) hh[i] = mdl::ReadLE32(hhb + 4*i);
        const uint32_t threads = 1024, start = 0x12345678u - 5;
        uint32_t target[8]; memset(target, 0, sizeof target);
        CU(cudaMemcpyToSymbol(c_hh, hh, 32));
        CU(cudaMemcpyToSymbol(c_target, target, 32));
        if (!dbg_d) CU(cudaMalloc(&dbg_d, threads * 32));
        CU(cudaMemset(out_d, 0, sizeof(MineOut)));
        mine_kernel<<<threads / 128, 128>>>(dag, (uint32_t)(ed->sz.full_size / 128), start, out_d, dbg_d);
        CU(cudaGetLastError()); CU(cudaDeviceSynchronize());
        std::vector<uint32_t> res(threads * 8);
        CU(cudaMemcpy(res.data(), dbg_d, threads * 32, cudaMemcpyDeviceToHost));
        const uint32_t idx[6] = {0, 5, 7, 8, 513, 1023};
        for (uint32_t k : idx) {
            uint8_t cpu[32]; mdl::hashimoto_light(ed->sz.full_size, ed->cache, hhb, (uint64_t)(start + k), cpu);
            if (memcmp(cpu, &res[k * 8], 32)) { logf("GPU%d SELFTEST FAILED: hash for nonce %08x differs from CPU", dev, start + k); return false; }
        }
        if (epoch == 0 && ed->sz.full_size == 4294962304ULL) {   // vector from tests/test_core.cpp (node code)
            U256 v = from_le_bytes((const uint8_t*)&res[5 * 8]);
            if (u256_hex(v) != "32f168d060b1854031b2695ec2f68823292886a3b7cd84d391dc2ead56f286e7") {
                logf("GPU%d SELFTEST FAILED: mainnet epoch-0 vector mismatch", dev); return false;
            }
        }
        logf("GPU%d: self-test passed (16 DAG items + 6 hashes match the node algorithm)", dev);
        return true;
    }

    bool init() {
#if CUDART_VERSION >= 12000
        cudaInitDevice(dev, cudaDeviceScheduleBlockingSync, 0);  // don't burn a CPU core per GPU
#endif
        CU(cudaSetDevice(dev));
#if CUDART_VERSION < 12000
        cudaSetDeviceFlags(cudaDeviceScheduleBlockingSync);
#endif
        cudaDeviceProp p; CU(cudaGetDeviceProperties(&p, dev));
        st->name = p.name;
        logf("GPU%d: %s, %.1f GiB, compute %d.%d, PCI %02x:%02x", dev, p.name, p.totalGlobalMem / 1073741824.0, p.major, p.minor, p.pciBusID, p.pciDeviceID);
        CU(cudaMalloc(&out_d, sizeof(MineOut)));
        return true;
    }

    bool ensure_epoch(uint32_t ntime, const mdl::Params& P) {
        mdl::EpochSizing sz = mdl::sizing(ntime, P);
        if (sz.epoch == epoch && dag) return true;
        return build_dag(get_epoch(ntime, P));
    }

    // Mine one batch; returns candidate nonces.
    bool launch(uint32_t start, uint32_t count, std::vector<uint32_t>& found) {
        CU(cudaMemset(out_d, 0, sizeof(uint32_t)));
        mine_kernel<<<count / 128, 128>>>(dag, (uint32_t)(ed->sz.full_size / 128), start, out_d, nullptr);
        CU(cudaGetLastError());
        MineOut h; CU(cudaMemcpy(&h, out_d, sizeof h, cudaMemcpyDeviceToHost));
        found.assign(h.nonce, h.nonce + std::min<uint32_t>(h.count, MAX_RESULTS));
        return true;
    }
};

static void wait_new_job(Stratum* sm, uint64_t seq) {
    for (int i = 0; i < 250 && !g_stop && sm->seq() == seq; i++) std::this_thread::sleep_for(std::chrono::milliseconds(20));
}

// CPU check of a candidate exactly as the pool's node will compute it.
static U256 cpu_pow(const std::vector<uint8_t>& header76, uint32_t nonce, const EpochData& ed) {
    uint8_t h80[80]; memcpy(h80, header76.data(), 76); mdl::WriteLE32(h80 + 76, nonce);
    uint8_t out[32]; mdl::pow_hash(h80, ed.sz.full_size, ed.cache, out);
    return from_le_bytes(out);
}

static void gpu_thread(int dev, GpuStats* st, Stratum* sm, const Options* o) {
    Gpu g{dev, st};
    if (!g.init()) return;
    mdl::Params P = mdl::mainnet_params(); P.base_time = o->base_time;
    const uint32_t batch = 1u << o->batch_log2;
    st->alive = true;

    if (o->benchmark || o->selftest_only) {
        uint32_t now = (uint32_t)time(nullptr);
        if (!g.ensure_epoch(now, P)) { st->alive = false; return; }
        if (o->selftest_only) { st->alive = false; return; }
        uint32_t hh[8]; std::mt19937 r(dev); for (auto& x : hh) x = r();
        uint32_t tgt[8] = {0}; cudaMemcpyToSymbol(c_hh, hh, 32); cudaMemcpyToSymbol(c_target, tgt, 32);
        std::vector<uint32_t> f; uint32_t nonce = 0;
        auto end = std::chrono::steady_clock::now() + std::chrono::seconds(o->bench_seconds);
        while (!g_stop && std::chrono::steady_clock::now() < end) {
            if (!g.launch(nonce, batch, f)) break;
            nonce += batch; st->hashes += batch;
        }
        st->alive = false; return;
    }

    std::vector<uint32_t> found;
    while (!g_stop) {
        Stratum::Snapshot s;
        if (!sm->snapshot(s)) { std::this_thread::sleep_for(std::chrono::milliseconds(100)); continue; }
        uint32_t ntime = 0, bits = 0;
        if (!hex_u32(s.job.ntime, ntime) || !hex_u32(s.job.nbits, bits)) { std::this_thread::sleep_for(std::chrono::milliseconds(200)); continue; }
        if (!g.ensure_epoch(ntime, P)) { logf("GPU%d stopped: DAG build or self-test failed", dev); break; }
        const std::string en2 = sm->next_en2(s.en2_size);
        std::vector<uint8_t> h76;
        if (!build_header76(s.job, s.en1, en2, h76)) { logf("GPU%d: malformed job %s", dev, s.job.id.c_str()); std::this_thread::sleep_for(std::chrono::seconds(1)); continue; }
        uint8_t hhb[32]; mdl::keccak256(h76.data(), 76, hhb);
        uint32_t hh[8]; for (int i = 0; i < 8; i++) hh[i] = mdl::ReadLE32(hhb + 4*i);
        const U256 share_t = diff_to_target(s.diff), net_t = bits_to_target(bits);
        const U256 use_t = cmp256(share_t, net_t) >= 0 ? share_t : net_t;   // easier one; a block always counts
        cudaMemcpyToSymbol(c_hh, hh, 32);
        cudaMemcpyToSymbol(c_target, use_t.w, 32);
        for (uint64_t start = 0; start < (1ULL << 32) && !g_stop; start += batch) {
            if (sm->seq() != s.seq) break;                 // new job / reconnect: refresh work
            if (!g.launch((uint32_t)start, batch, found)) { g_stop = true; break; }
            st->hashes += batch;
            bool block_sent = false;
            for (uint32_t nonce : found) {
                U256 v = cpu_pow(h76, nonce, *g.ed);
                if (cmp256(v, use_t) > 0) { st->hw_errors++; logf("GPU%d: result %08x failed CPU verification (not submitted)", dev, nonce); continue; }
                bool is_block = cmp256(v, net_t) <= 0;
                sm->submit(s, en2, nonce, value_to_diff(v), is_block, dev);
                if (is_block) { block_sent = true; break; }
            }
            if (block_sent) { wait_new_job(sm, s.seq); break; }
        }
    }
    st->alive = false;
}

// Hidden protocol test path: mine with the CPU light verifier (slow) to exercise the
// stratum/header/submit code end to end without a GPU. Only useful at tiny difficulty.
static void cpu_thread(Stratum* sm, const Options* o, GpuStats* st) {
    mdl::Params P = mdl::mainnet_params(); P.base_time = o->base_time;
    st->name = "CPU (protocol test)"; st->alive = true;
    while (!g_stop) {
        Stratum::Snapshot s;
        if (!sm->snapshot(s)) { std::this_thread::sleep_for(std::chrono::milliseconds(100)); continue; }
        uint32_t ntime, bits; hex_u32(s.job.ntime, ntime); hex_u32(s.job.nbits, bits);
        auto ed = get_epoch(ntime, P);
        const std::string en2 = sm->next_en2(s.en2_size);
        std::vector<uint8_t> h76; if (!build_header76(s.job, s.en1, en2, h76)) continue;
        const U256 share_t = diff_to_target(s.diff), net_t = bits_to_target(bits);
        const U256 use_t = cmp256(share_t, net_t) >= 0 ? share_t : net_t;
        for (uint32_t nonce = 0; !g_stop && sm->seq() == s.seq; nonce++) {
            U256 v = cpu_pow(h76, nonce, *ed); st->hashes++;
            if (cmp256(v, use_t) <= 0) {
                bool blk = cmp256(v, net_t) <= 0;
                sm->submit(s, en2, nonce, value_to_diff(v), blk, 0);
                if (blk) { wait_new_job(sm, s.seq); break; }
            }
        }
    }
}

// ───────────────────────── main ─────────────────────────
int main(int argc, char** argv) {
    setvbuf(stdout, nullptr, _IOLBF, 0);
    Options o;
    if (!parse_args(argc, argv, o)) { usage(); return 2; }
    signal(SIGINT, on_signal); signal(SIGTERM, on_signal); signal(SIGPIPE, SIG_IGN);
    printf("xcoin-cuda-miner %s — MetalDAG for NVIDIA (epoch base %llu)\n", VERSION, (unsigned long long)o.base_time);

    const bool need_pool = !(o.benchmark || o.selftest_only);
    if (need_pool) {
        if (o.pools.empty() || o.address.empty()) { usage(); return 2; }
        if (!valid_address(o.address)) {
            fprintf(stderr, "'%s' is not a valid xCoin payout address (expected xpa1r..., bech32m witness v3).\n", o.address.c_str());
            if (o.address.rfind("xid1", 0) == 0) fprintf(stderr, "xid1... is a forum identity, not a payout address.\n");
            return 2;
        }
    }

    int ndev = 0;
    if (!o.cpu_mine) {
        if (cudaGetDeviceCount(&ndev) != cudaSuccess || ndev == 0) { fprintf(stderr, "No CUDA devices found (check the NVIDIA driver).\n"); return 1; }
        if (o.devices.empty()) for (int i = 0; i < ndev; i++) o.devices.push_back(i);
        for (int d : o.devices) if (d < 0 || d >= ndev) { fprintf(stderr, "device %d does not exist (have %d)\n", d, ndev); return 2; }
    }

    std::string user = o.address + "." + o.worker;
    std::unique_ptr<Stratum> sm;
    if (need_pool) {
        sm.reset(new Stratum(o.pools, user, o.password, std::string("xcoin-cuda-miner/") + VERSION + " MetalDAG"));
        sm->start();
    }

    const size_t nst = o.cpu_mine ? 1 : o.devices.size();
    std::vector<std::unique_ptr<GpuStats>> stats(nst);
    for (auto& s : stats) s.reset(new GpuStats());
    std::vector<std::thread> th;
    if (o.cpu_mine) th.emplace_back(cpu_thread, sm.get(), &o, stats[0].get());
    else for (size_t i = 0; i < o.devices.size(); i++) th.emplace_back(gpu_thread, o.devices[i], stats[i].get(), sm.get(), &o);

    auto t_start = std::chrono::steady_clock::now();
    auto t_last = t_start;
    std::vector<uint64_t> last(nst, 0);
    while (!g_stop) {
        for (int i = 0; i < 10 && !g_stop; i++) std::this_thread::sleep_for(std::chrono::seconds(1));
        auto now = std::chrono::steady_clock::now();
        double dt = std::chrono::duration<double>(now - t_last).count(); t_last = now;
        double total = 0; std::string line; bool any_alive = false;
        for (size_t i = 0; i < nst; i++) {
            uint64_t h = stats[i]->hashes.load();
            double hps = (h - last[i]) / std::max(dt, 1e-3); last[i] = h;
            stats[i]->hps = stats[i]->hps == 0 ? hps : 0.6 * stats[i]->hps + 0.4 * hps;
            total += stats[i]->hps; any_alive |= stats[i]->alive.load();
            char b[96]; snprintf(b, sizeof b, "%sGPU%d %.2f MH/s", i ? " | " : "", o.cpu_mine ? 0 : o.devices[i], stats[i]->hps / 1e6); line += b;
        }
        if (sm) {
            logf("%s | total %.2f MH/s | A %llu R %llu | diff %.4g | %s", line.c_str(), total / 1e6,
                 (unsigned long long)sm->accepted.load(), (unsigned long long)sm->rejected.load(), sm->difficulty(), sm->pool_name().c_str());
            sm->report_hashrate(total);
        } else logf("%s | total %.2f MH/s", line.c_str(), total / 1e6);
        if (!o.stats_file.empty()) {
            std::string js = "{\"ver\":\"" + std::string(VERSION) + "\",\"uptime\":" +
                std::to_string((long long)std::chrono::duration<double>(now - t_start).count()) + ",\"hs\":[";
            for (size_t i = 0; i < nst; i++) { char b[32]; snprintf(b, sizeof b, "%s%.0f", i ? "," : "", stats[i]->hps); js += b; }
            js += "],\"total_hs\":" + std::to_string((long long)total) + ",\"accepted\":" + std::to_string(sm ? sm->accepted.load() : 0) +
                  ",\"rejected\":" + std::to_string(sm ? sm->rejected.load() : 0) + ",\"hw_errors\":[";
            for (size_t i = 0; i < nst; i++) js += (i ? "," : "") + std::to_string(stats[i]->hw_errors.load());
            js += "]}\n";
            std::string tmp = o.stats_file + ".tmp";
            { std::ofstream f(tmp); f << js; }
            rename(tmp.c_str(), o.stats_file.c_str());
        }
        if (!any_alive && std::chrono::duration<double>(now - t_start).count() > 30 && !o.cpu_mine) {
            if (!o.benchmark && !o.selftest_only) logf("no GPU is mining any more; exiting");
            g_stop = true;
        }
        if ((o.benchmark || o.selftest_only) && !any_alive && std::chrono::duration<double>(now - t_start).count() > 2) g_stop = true;
    }
    g_stop = true;
    if (sm) sm->stop = true;
    for (auto& t : th) t.join();
    if (sm) sm->join();
    printf("bye\n");
    return 0;
}
