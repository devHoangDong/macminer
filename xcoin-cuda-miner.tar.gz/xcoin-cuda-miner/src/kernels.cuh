// kernels.cuh — CUDA kernels: DAG generation and the MetalDAG mining hot path.
#pragma once
#include "hashcore.h"

#define MAX_RESULTS 32
struct MineOut { uint32_t count; uint32_t nonce[MAX_RESULTS]; };

__constant__ uint32_t c_hh[8];       // keccak256(header76), 8 LE words
__constant__ uint32_t c_target[8];   // 256-bit target, most-significant word first

// One thread per 64-byte DAG item.
__global__ void build_dag_kernel(const uint32_t* __restrict__ cache, uint32_t n,
                                 uint4* __restrict__ dag, uint64_t start, uint64_t items) {
    const uint64_t i = start + (uint64_t)blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= items) return;
    uint32_t o[16];
    dag_item(cache, n, i, o);
    uint4* d = dag + i * 4;
    d[0] = make_uint4(o[0], o[1], o[2], o[3]);
    d[1] = make_uint4(o[4], o[5], o[6], o[7]);
    d[2] = make_uint4(o[8], o[9], o[10], o[11]);
    d[3] = make_uint4(o[12], o[13], o[14], o[15]);
}

#define FULL_MASK 0xffffffffu
#define TPH 8   // threads cooperating per hash: each owns 16 bytes of the 128-byte mix

// Hashimoto with 8 cooperating lanes (Ethash "shuffled" layout): every lane computes
// keccak512 for its own nonce, then the group walks the 8 hashes in turn; lane t keeps
// mix words 4t..4t+3 and loads uint4 #t of each 128-byte DAG pair, so each access is
// one coalesced 128-byte read. Bit-identical to hashimoto_full() (tests/test_core.cpp).
// blockDim.x must be a multiple of 32; every launched thread is a real nonce.
__global__ void __launch_bounds__(128)
mine_kernel(const uint4* __restrict__ dag, uint32_t pairs, uint32_t start_nonce,
            MineOut* __restrict__ out, uint32_t* __restrict__ dbg) {
    const uint32_t gid = blockIdx.x * blockDim.x + threadIdx.x;
    const uint32_t nonce = start_nonce + gid;
    const int lane = threadIdx.x & (TPH - 1);
    const int q = lane & 3;                        // which 4 words of s seed this lane's mix

    uint32_t s[16];
    {
        uint32_t in10[10];
        UNROLL for (int i = 0; i < 8; i++) in10[i] = c_hh[i];
        in10[8] = nonce; in10[9] = 0;
        keccak512_40(in10, s);
    }

    uint32_t cm[8];
    #pragma unroll 1
    for (int h = 0; h < TPH; h++) {
        uint32_t sh[16];
        UNROLL for (int k = 0; k < 16; k++) sh[k] = __shfl_sync(FULL_MASK, s[k], h, TPH);
        const uint32_t init0 = sh[0];
        uint4 mix;
        mix.x = q == 0 ? sh[0] : q == 1 ? sh[4] : q == 2 ? sh[8]  : sh[12];
        mix.y = q == 0 ? sh[1] : q == 1 ? sh[5] : q == 2 ? sh[9]  : sh[13];
        mix.z = q == 0 ? sh[2] : q == 1 ? sh[6] : q == 2 ? sh[10] : sh[14];
        mix.w = q == 0 ? sh[3] : q == 1 ? sh[7] : q == 2 ? sh[11] : sh[15];

        #pragma unroll 2
        for (uint32_t a = 0; a < 64; a += 4) {
            const int t = (a >> 2) & 7;            // lane holding mix word (a % 32)
            UNROLL for (uint32_t b = 0; b < 4; b++) {
                const uint32_t m = b == 0 ? mix.x : b == 1 ? mix.y : b == 2 ? mix.z : mix.w;
                uint32_t off = fnv(init0 ^ (a + b), m) % pairs;
                off = __shfl_sync(FULL_MASK, off, t, TPH);
                const uint4 d = __ldg(&dag[(uint64_t)off * TPH + lane]);
                mix.x = fnv(mix.x, d.x); mix.y = fnv(mix.y, d.y);
                mix.z = fnv(mix.z, d.z); mix.w = fnv(mix.w, d.w);
            }
        }
        const uint32_t r = fnv(fnv(fnv(mix.x, mix.y), mix.z), mix.w);
        UNROLL for (int w = 0; w < 8; w++) {
            const uint32_t v = __shfl_sync(FULL_MASK, r, w, TPH);
            if (lane == h) cm[w] = v;
        }
    }

    uint32_t fin[24], res[8];
    UNROLL for (int i = 0; i < 16; i++) fin[i] = s[i];
    UNROLL for (int i = 0; i < 8; i++) fin[16 + i] = cm[i];
    keccak256_96(fin, res);

    if (dbg) { UNROLL for (int i = 0; i < 8; i++) dbg[(uint64_t)gid * 8 + i] = res[i]; }

    // res[7] is the numeric most-significant word (node uint256 is little-endian).
    bool below = false;
    UNROLL for (int i = 0; i < 8; i++) {
        const uint32_t hw = res[7 - i], tw = c_target[i];
        if (hw != tw) { below = hw < tw; break; }
        if (i == 7) below = true;                  // equal counts: node accepts hash <= target
    }
    if (below) {
        const uint32_t idx = atomicAdd(&out->count, 1u);
        if (idx < MAX_RESULTS) out->nonce[idx] = nonce;
    }
}
