// stratum.h — stratum v1 client for xcoin-pool (solo :3335 / PPLNS :3336).
// One TCP connection per process; GPU threads take job snapshots and submit shares.
#pragma once
#include <arpa/inet.h>
#include <fcntl.h>
#include <netdb.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <poll.h>
#include <sys/socket.h>
#include <unistd.h>
#include <atomic>
#include <chrono>
#include <map>
#include <mutex>
#include <string>
#include <thread>
#include <vector>
#include "json.h"
#include "log.h"
#include "work.h"

struct PoolAddr { std::string host; std::string port; };

class Stratum {
public:
    struct Snapshot { Job job; std::string en1; int en2_size = 4; double diff = 1; uint64_t seq = 0; };

    std::atomic<uint64_t> accepted{0}, rejected{0}, blocks_found{0}, stale_or_bad{0}, throttled{0};
    std::atomic<bool> stop{false};

    Stratum(std::vector<PoolAddr> pools, std::string user, std::string pass, std::string agent)
        : pools_(std::move(pools)), user_(std::move(user)), pass_(std::move(pass)), agent_(std::move(agent)) {}

    void start() { th_ = std::thread([this] { run(); }); }
    void join() { if (th_.joinable()) th_.join(); }

    // Copy of the current job; false when there is no valid work (disconnected, no job yet).
    bool snapshot(Snapshot& s) {
        std::lock_guard<std::mutex> lk(m_);
        if (!have_job_) return false;
        s = cur_; return true;
    }
    uint64_t seq() const { return seq_.load(); }
    double difficulty() { std::lock_guard<std::mutex> lk(m_); return diff_; }
    std::string pool_name() { std::lock_guard<std::mutex> lk(m_); return pools_[pidx_].host + ":" + pools_[pidx_].port; }

    std::string next_en2(int size) {
        uint64_t v = en2_counter_.fetch_add(1);
        std::string s; char b[3];
        for (int i = size - 1; i >= 0; i--) { snprintf(b, 3, "%02x", (unsigned)((i < 8) ? (v >> (8*i)) & 0xff : 0)); s += b; }
        return s;
    }

    void submit(const Snapshot& s, const std::string& en2, uint32_t nonce, double share_diff, bool is_block, int gpu) {
        char nh[9]; snprintf(nh, sizeof nh, "%08x", nonce);   // pool parses int(nonce, 16)
        std::lock_guard<std::mutex> lk(m_);
        // The pool keeps recent jobs valid until the tip moves (a clean job). A share from a
        // job older than the last clean job is stale and would be rejected: drop it here.
        if (fd_ < 0 || s.seq < clean_seq_) { stale_or_bad++; return; }
        // xcoin-pool refuses more than 20 submits/s per connection and drops a flooder.
        // Keep well under it; a block is never held back.
        auto now = std::chrono::steady_clock::now();
        while (!sub_times_.empty() && now - sub_times_.front() > std::chrono::seconds(1)) sub_times_.erase(sub_times_.begin());
        if (!is_block && sub_times_.size() >= 10) { throttled++; return; }
        sub_times_.push_back(now);
        int id = next_id_++;
        pending_[id] = Pending{share_diff, is_block, gpu};
        std::string msg = "{\"id\":" + std::to_string(id) + ",\"method\":\"mining.submit\",\"params\":[\"" +
            json_escape(user_) + "\",\"" + json_escape(s.job.id) + "\",\"" + en2 + "\",\"" + json_escape(s.job.ntime) + "\",\"" + nh + "\"]}\n";
        send_locked(msg);
        if (is_block) logf("GPU%d BLOCK CANDIDATE nonce=%s diff=%.6g -> submitted", gpu, nh, share_diff);
    }

    void report_hashrate(double hps) {
        std::lock_guard<std::mutex> lk(m_);
        if (fd_ < 0 || !authorized_) return;
        char b[160]; snprintf(b, sizeof b, "{\"id\":null,\"method\":\"mining.hashrate\",\"params\":[%.0f]}\n", hps);
        send_locked(b);
    }

private:
    struct Pending { double diff; bool block; int gpu; };
    std::vector<PoolAddr> pools_; std::string user_, pass_, agent_;
    std::thread th_; std::mutex m_;
    int fd_ = -1; size_t pidx_ = 0; int next_id_ = 3;
    bool authorized_ = false, have_job_ = false;
    std::string en1_; int en2_size_ = 4; double diff_ = 1.0;
    Snapshot cur_; std::atomic<uint64_t> seq_{1}, en2_counter_{0}; uint64_t clean_seq_ = 0;
    std::map<int, Pending> pending_;
    std::string rx_;
    std::vector<std::chrono::steady_clock::time_point> sub_times_;

    void send_locked(const std::string& s) {
        if (fd_ < 0) return;
        size_t off = 0;
        while (off < s.size()) {
            ssize_t n = ::send(fd_, s.data() + off, s.size() - off, MSG_NOSIGNAL);
            if (n <= 0) { ::close(fd_); fd_ = -1; return; }
            off += (size_t)n;
        }
    }

    int dial(const PoolAddr& p) {
        addrinfo hints{}, *res = nullptr; hints.ai_family = AF_UNSPEC; hints.ai_socktype = SOCK_STREAM;
        if (getaddrinfo(p.host.c_str(), p.port.c_str(), &hints, &res) != 0 || !res) { logf("pool %s: cannot resolve", p.host.c_str()); return -1; }
        int fd = -1;
        for (addrinfo* ai = res; ai; ai = ai->ai_next) {
            fd = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
            if (fd < 0) continue;
            int fl = fcntl(fd, F_GETFL, 0); fcntl(fd, F_SETFL, fl | O_NONBLOCK);
            int rc = connect(fd, ai->ai_addr, ai->ai_addrlen);
            if (rc < 0 && errno == EINPROGRESS) {
                pollfd pf{fd, POLLOUT, 0};
                if (poll(&pf, 1, 10000) == 1) { int err = 0; socklen_t l = sizeof err; getsockopt(fd, SOL_SOCKET, SO_ERROR, &err, &l); rc = err ? -1 : 0; }
                else rc = -1;
            }
            if (rc == 0) {
                fcntl(fd, F_SETFL, fl);
                int one = 1; setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &one, sizeof one); setsockopt(fd, SOL_SOCKET, SO_KEEPALIVE, &one, sizeof one);
                break;
            }
            ::close(fd); fd = -1;
        }
        freeaddrinfo(res);
        return fd;
    }

    void invalidate_locked() { have_job_ = false; authorized_ = false; clean_seq_ = ++seq_; pending_.clear(); }

    void run() {
        int fails = 0;
        while (!stop) {
            PoolAddr p; { std::lock_guard<std::mutex> lk(m_); p = pools_[pidx_]; }
            logf("connecting to %s:%s ...", p.host.c_str(), p.port.c_str());
            int fd = dial(p);
            if (fd < 0) {
                logf("pool %s:%s unreachable", p.host.c_str(), p.port.c_str());
                fails++;
                { std::lock_guard<std::mutex> lk(m_); if (pools_.size() > 1 && fails % 2 == 0) pidx_ = (pidx_ + 1) % pools_.size(); }
                for (int i = 0; i < 10 && !stop; i++) std::this_thread::sleep_for(std::chrono::seconds(1));
                continue;
            }
            {
                std::lock_guard<std::mutex> lk(m_);
                fd_ = fd; rx_.clear(); next_id_ = 3;
                send_locked("{\"id\":1,\"method\":\"mining.subscribe\",\"params\":[\"" + json_escape(agent_) + "\"]}\n");
                send_locked("{\"id\":2,\"method\":\"mining.authorize\",\"params\":[\"" + json_escape(user_) + "\",\"" + json_escape(pass_) + "\"]}\n");
            }
            logf("connected, subscribing as %s", user_.c_str());
            bool alive = true;
            while (alive && !stop) {
                pollfd pf{fd, POLLIN, 0};
                int pr = poll(&pf, 1, 1000);
                if (pr < 0) { alive = false; break; }
                { std::lock_guard<std::mutex> lk(m_); if (fd_ < 0) { alive = false; break; } }
                if (pr == 0) continue;
                char buf[65536];
                ssize_t n = recv(fd, buf, sizeof buf, 0);
                if (n <= 0) { alive = false; break; }
                rx_.append(buf, (size_t)n);
                if (rx_.size() > (16u << 20)) { logf("pool sent an oversized line; reconnecting"); alive = false; break; }
                size_t nl;
                while ((nl = rx_.find('\n')) != std::string::npos) {
                    std::string line = rx_.substr(0, nl); rx_.erase(0, nl + 1);
                    if (!line.empty()) handle(line);
                }
            }
            {
                std::lock_guard<std::mutex> lk(m_);
                if (fd_ >= 0) ::close(fd_);
                fd_ = -1; invalidate_locked();
            }
            if (!stop) { logf("disconnected from pool; retrying in 5 s"); fails++; for (int i = 0; i < 5 && !stop; i++) std::this_thread::sleep_for(std::chrono::seconds(1)); }
        }
    }

    void handle(const std::string& line) {
        JVal j; if (!JParser::parse(line, j) || j.t != JVal::Obj) return;
        const JVal* method = j.get("method");
        const JVal* params = j.get("params");
        if (method && method->t == JVal::Str) {
            const std::string& m = method->s;
            if (m == "mining.set_difficulty" && params && !params->a.empty() && params->a[0].t == JVal::Num) {
                std::lock_guard<std::mutex> lk(m_);
                diff_ = params->a[0].n > 0 ? params->a[0].n : 1e-9;
                logf("pool difficulty %.6g", diff_);
            } else if (m == "mining.notify" && params && params->a.size() >= 9) {
                auto& p = params->a;
                Job jb; jb.id = p[0].str(); jb.prevhash = p[1].str(); jb.cb1 = p[2].str(); jb.cb2 = p[3].str();
                for (auto& b : p[4].a) jb.branches.push_back(b.str());
                jb.version = p[5].str(); jb.nbits = p[6].str(); jb.ntime = p[7].str(); jb.clean = p[8].t == JVal::Bool && p[8].b;
                std::lock_guard<std::mutex> lk(m_);
                cur_.job = jb; cur_.en1 = en1_; cur_.en2_size = en2_size_; cur_.diff = diff_;
                cur_.seq = ++seq_; have_job_ = !en1_.empty();
                if (jb.clean) clean_seq_ = cur_.seq;
            } else if (m == "client.show_message" && params && !params->a.empty()) {
                logf("pool says: %s", params->a[0].str().c_str());
            } else if (m == "mining.block_found") {
                logf("pool: block found %s", line.c_str());
            }
            return;
        }
        const JVal* id = j.get("id");
        if (!id || id->t != JVal::Num) return;
        int iid = (int)id->n;
        const JVal* res = j.get("result");
        const JVal* err = j.get("error");
        std::string why = "unknown";
        if (err && err->t == JVal::Arr && err->a.size() > 1) why = err->a[1].str(why);
        else if (const JVal* rr = j.get("reject-reason")) why = rr->str(why);
        std::lock_guard<std::mutex> lk(m_);
        if (iid == 1) {
            if (res && res->t == JVal::Arr && res->a.size() >= 3) {
                en1_ = res->a[1].str(); en2_size_ = res->a[2].t == JVal::Num ? (int)res->a[2].n : 4;
                if (en2_size_ < 1 || en2_size_ > 16) en2_size_ = 4;
                logf("subscribed: extranonce1=%s extranonce2_size=%d", en1_.c_str(), en2_size_);
            } else logf("subscribe failed: %s", why.c_str());
        } else if (iid == 2) {
            if (res && res->t == JVal::Bool && res->b) { authorized_ = true; logf("authorized"); }
            else logf("authorize REFUSED: %s", why.c_str());
        } else {
            auto it = pending_.find(iid);
            Pending pd = it != pending_.end() ? it->second : Pending{0, false, -1};
            if (it != pending_.end()) pending_.erase(it);
            if (res && res->t == JVal::Bool && res->b) {
                accepted++; if (pd.block) blocks_found++;
                logf("GPU%d share accepted (diff %.4g)%s  [A %llu / R %llu]", pd.gpu, pd.diff, pd.block ? " *** BLOCK ***" : "",
                     (unsigned long long)accepted.load(), (unsigned long long)rejected.load());
            } else {
                rejected++;
                logf("GPU%d share REJECTED: %s  [A %llu / R %llu]", pd.gpu, why.c_str(),
                     (unsigned long long)accepted.load(), (unsigned long long)rejected.load());
            }
        }
    }
};
