// work.h — stratum job -> 76-byte header, targets, and 256-bit helpers.
// Byte layouts follow xcoin-pool.py (notify()/validate()) exactly.
#pragma once
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <string>
#include <vector>
#include "sha256.h"

inline int hexval(char c) { if (c >= '0' && c <= '9') return c - '0'; if (c >= 'a' && c <= 'f') return c - 'a' + 10; if (c >= 'A' && c <= 'F') return c - 'A' + 10; return -1; }
inline bool from_hex(const std::string& h, std::vector<uint8_t>& out) {
    if (h.size() % 2) return false; out.clear(); out.reserve(h.size() / 2);
    for (size_t i = 0; i < h.size(); i += 2) { int a = hexval(h[i]), b = hexval(h[i+1]); if (a < 0 || b < 0) return false; out.push_back((uint8_t)(a << 4 | b)); }
    return true;
}
inline std::string to_hex(const uint8_t* d, size_t n) { static const char* x = "0123456789abcdef"; std::string s; s.reserve(2*n); for (size_t i = 0; i < n; i++) { s += x[d[i] >> 4]; s += x[d[i] & 15]; } return s; }

struct Job {
    std::string id, prevhash, cb1, cb2, version, nbits, ntime;
    std::vector<std::string> branches;
    bool clean = false;
};

inline bool hex_u32(const std::string& h, uint32_t& v) {
    if (h.empty() || h.size() > 8) return false;
    v = 0; for (char c : h) { int d = hexval(c); if (d < 0) return false; v = (v << 4) | (uint32_t)d; } return true;
}
inline void put_le32(std::vector<uint8_t>& o, uint32_t v) { o.push_back(v); o.push_back(v >> 8); o.push_back(v >> 16); o.push_back(v >> 24); }

// header76 = version LE | prev_le | merkle root | ntime LE | nbits LE
// The pool sends prevhash as 8 little-endian words of prev_le; the merkle branches
// are ready-to-hash bytes (branch_le); the root is SHA-256d as in Bitcoin.
inline bool build_header76(const Job& j, const std::string& en1, const std::string& en2, std::vector<uint8_t>& h) {
    std::vector<uint8_t> prev, cb;
    if (!from_hex(j.prevhash, prev) || prev.size() != 32) return false;
    if (!from_hex(j.cb1 + en1 + en2 + j.cb2, cb)) return false;
    uint32_t ver, bits, ntime;
    if (!hex_u32(j.version, ver) || !hex_u32(j.nbits, bits) || !hex_u32(j.ntime, ntime)) return false;
    std::vector<uint8_t> root = sha::sha256d(cb);
    for (auto& bh : j.branches) {
        std::vector<uint8_t> b; if (!from_hex(bh, b) || b.size() != 32) return false;
        std::vector<uint8_t> cat(root); cat.insert(cat.end(), b.begin(), b.end());
        root = sha::sha256d(cat);
    }
    h.clear(); h.reserve(80);
    put_le32(h, ver);
    for (int w = 0; w < 8; w++) for (int k = 3; k >= 0; k--) h.push_back(prev[4*w + k]);  // un-swap words
    h.insert(h.end(), root.begin(), root.end());
    put_le32(h, ntime);
    put_le32(h, bits);
    return true;
}

// 256-bit values as 8 x uint32, most-significant word first ("MSW-first").
struct U256 { uint32_t w[8] = {0}; };
inline int cmp256(const U256& a, const U256& b) { for (int i = 0; i < 8; i++) { if (a.w[i] != b.w[i]) return a.w[i] < b.w[i] ? -1 : 1; } return 0; }
// little-endian 32-byte PoW result (as the node's uint256) -> MSW-first
inline U256 from_le_bytes(const uint8_t* b) { U256 r; for (int i = 0; i < 8; i++) { int o = 4 * (7 - i); r.w[i] = (uint32_t)b[o] | (uint32_t)b[o+1] << 8 | (uint32_t)b[o+2] << 16 | (uint32_t)b[o+3] << 24; } return r; }
inline U256 shl_u64(uint64_t v, int sh) {  // v << sh, saturating at 2^256-1
    U256 r; if (v == 0) return r;
    if (sh < 0) { v = (-sh >= 64) ? 0 : (v >> -sh); sh = 0; }
    int top = 63 - __builtin_clzll(v ? v : 1);
    if (v && top + sh > 255) { for (auto& x : r.w) x = 0xFFFFFFFFu; return r; }
    for (int bit = 0; bit < 64; bit++) if ((v >> bit) & 1) { int pos = bit + sh; if (pos < 256) r.w[7 - pos / 32] |= 1u << (pos % 32); }
    return r;
}
// Pool: bits_to_target(bits) = mant << 8*(exp-3)  (mant = bits & 0xffffff)
inline U256 bits_to_target(uint32_t bits) {
    uint32_t exp = bits >> 24; uint64_t mant = bits & 0xffffff;
    return exp > 3 ? shl_u64(mant, 8 * ((int)exp - 3)) : shl_u64(mant >> (8 * (3 - exp)), 0);
}
// Pool: diff_to_target(d) = int(MAX_TARGET / d) with MAX_TARGET = 0xFFFF << 208, in IEEE double.
inline U256 diff_to_target(double d) {
    const double MAXT = std::ldexp(65535.0, 208);
    if (!(d > 0)) return shl_u64(0xFFFF, 208);
    double t = MAXT / d;
    if (!std::isfinite(t) || t >= std::ldexp(1.0, 256)) { U256 r; for (auto& x : r.w) x = 0xFFFFFFFFu; return r; }
    if (t < 1) return U256{};
    int e; double m = std::frexp(t, &e);                   // t = m * 2^e, 0.5 <= m < 1
    uint64_t mant = (uint64_t)std::ldexp(m, 53);          // exact 53-bit mantissa
    return shl_u64(mant, e - 53);                         // int() truncation for e < 53
}
// share difficulty of a PoW value: MAX_TARGET / value
inline double value_to_diff(const U256& v) {
    double x = 0; for (int i = 0; i < 8; i++) x = x * 4294967296.0 + v.w[i];
    return x > 0 ? std::ldexp(65535.0, 208) / x : 0;
}
inline std::string u256_hex(const U256& v) { char b[65]; for (int i = 0; i < 8; i++) snprintf(b + 8*i, 9, "%08x", v.w[i]); return b; }
