// json.h — minimal JSON reader for stratum messages (objects, arrays, strings,
// numbers, bools, null). Untrusted input: never throws, marks failure instead.
#pragma once
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <utility>
#include <vector>

struct JVal {
    enum T { Null, Bool, Num, Str, Arr, Obj } t = Null;
    bool b = false; double n = 0; std::string s;
    std::vector<JVal> a; std::vector<std::pair<std::string, JVal>> o;
    const JVal* get(const char* k) const { if (t != Obj) return nullptr; for (auto& kv : o) if (kv.first == k) return &kv.second; return nullptr; }
    bool isNull() const { return t == Null; }
    std::string str(const std::string& d = "") const { return t == Str ? s : d; }
};

class JParser {
    const char* p; const char* e; int depth = 0;
    void ws() { while (p < e && (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r')) p++; }
    bool lit(const char* w) { size_t n = strlen(w); if ((size_t)(e - p) < n || strncmp(p, w, n)) return false; p += n; return true; }
    static void put_utf8(std::string& out, unsigned cp) {
        if (cp < 0x80) out += (char)cp;
        else if (cp < 0x800) { out += (char)(0xC0 | (cp >> 6)); out += (char)(0x80 | (cp & 0x3F)); }
        else { out += (char)(0xE0 | (cp >> 12)); out += (char)(0x80 | ((cp >> 6) & 0x3F)); out += (char)(0x80 | (cp & 0x3F)); }
    }
    bool str(std::string& out) {
        if (p >= e || *p != '"') return false;
        p++;
        while (p < e && *p != '"') {
            if (*p == '\\') {
                if (++p >= e) return false;
                switch (*p) {
                    case 'n': out += '\n'; break; case 't': out += '\t'; break; case 'r': out += '\r'; break;
                    case 'b': out += '\b'; break; case 'f': out += '\f'; break;
                    case 'u': { if (e - p < 5) return false; unsigned cp = (unsigned)strtoul(std::string(p + 1, 4).c_str(), nullptr, 16); put_utf8(out, cp); p += 4; break; }
                    default: out += *p;
                }
                p++;
            } else out += *p++;
        }
        if (p >= e) return false;
        p++;
        return true;
    }
    bool val(JVal& v) {
        if (++depth > 64) return false;
        ws(); if (p >= e) return false;
        bool ok = true;
        if (*p == '{') {
            v.t = JVal::Obj; p++; ws();
            if (p < e && *p == '}') { p++; }
            else for (;;) {
                ws(); std::string k; if (!str(k)) { ok = false; break; }
                ws(); if (p >= e || *p != ':') { ok = false; break; } p++;
                JVal c; if (!val(c)) { ok = false; break; }
                v.o.emplace_back(std::move(k), std::move(c));
                ws(); if (p < e && *p == ',') { p++; continue; }
                if (p < e && *p == '}') { p++; break; }
                ok = false; break;
            }
        } else if (*p == '[') {
            v.t = JVal::Arr; p++; ws();
            if (p < e && *p == ']') { p++; }
            else for (;;) {
                JVal c; if (!val(c)) { ok = false; break; }
                v.a.push_back(std::move(c));
                ws(); if (p < e && *p == ',') { p++; continue; }
                if (p < e && *p == ']') { p++; break; }
                ok = false; break;
            }
        } else if (*p == '"') { v.t = JVal::Str; ok = str(v.s); }
        else if (lit("true")) { v.t = JVal::Bool; v.b = true; }
        else if (lit("false")) { v.t = JVal::Bool; v.b = false; }
        else if (lit("null")) { v.t = JVal::Null; }
        else {
            std::string num; while (p < e && strchr("+-0123456789.eE", *p)) num += *p++;
            if (num.empty()) ok = false; else { v.t = JVal::Num; v.n = strtod(num.c_str(), nullptr); }
        }
        depth--; return ok;
    }
public:
    static bool parse(const std::string& in, JVal& out) { JParser j; j.p = in.data(); j.e = in.data() + in.size(); return j.val(out); }
};

inline std::string json_escape(const std::string& s) {
    std::string o; for (char c : s) { if (c == '"' || c == '\\') { o += '\\'; o += c; } else if ((unsigned char)c < 0x20) { char b[8]; snprintf(b, sizeof b, "\\u%04x", c); o += b; } else o += c; } return o;
}
