#pragma once
#include <cstdarg>
#include <cstdio>
#include <ctime>
#include <mutex>
inline std::mutex& log_mutex() { static std::mutex m; return m; }
inline void logf(const char* fmt, ...) {
    std::lock_guard<std::mutex> lk(log_mutex());
    time_t t = time(nullptr); struct tm tm; localtime_r(&t, &tm);
    char ts[32]; strftime(ts, sizeof ts, "%H:%M:%S", &tm);
    printf("[%s] ", ts);
    va_list ap; va_start(ap, fmt); vprintf(fmt, ap); va_end(ap);
    printf("\n"); fflush(stdout);
}
